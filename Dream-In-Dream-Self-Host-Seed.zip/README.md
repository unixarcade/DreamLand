# DREAM // IN // DREAM

```text
╲│╱                    ⚡──↯──⚡                    ╱│╲

                         DREAM
                           │
                           ▼
                    DREAM VM IN DREAM
                           │
                           ▼
                       RAW MEMORY
                           │
                           ▼
                        x86-64
                           │
                           ▼
                           42

╱│╲                    ⚡──↯──⚡                    ╲│╱
```

**The last bootstrap exercise.**

`DREAM_IN_DREAM.dc` implements a small executable Dream machine **in Dream itself**.
It is not a C block wearing a Dream costume. The runtime, assembler, stacks,
variables, control flow, memory operations, and dispatch loop are ordinary Dream C.

## WHAT IS INSIDE

The inner machine has:

- its own bytecode buffer
- its own variable cells
- its own data stack
- its own call stack
- arithmetic + bitwise operations
- comparisons
- load/store
- jumps
- calls + returns
- allocation/free
- `peek8` / `poke8`
- `peek64` / `poke64`
- output
- native function execution
- an x86-64 escape gate

The outer Dream program includes a tiny assembler implemented with Dream labels and
memory writes. It constructs an inner program, then the Dream-written VM executes it.

## THE PROOF

The inner program first computes:

```text
6 * 7
```

and prints:

```text
42
```

Then it counts `0..7` using an inner variable, comparison, and conditional jump.

Finally — from *inside the inner Dream* — it allocates executable memory and writes:

```asm
B8 2A 00 00 00 C3
```

which is:

```asm
mov eax, 42
ret
```

Then the inner Dream executes those bytes and prints the returned `42`.

```text
Dream source
    ↓
outer Dream compiler
    ↓
outer DRM3 VM / native Dream runtime
    ↓
Dream-written inner assembler
    ↓
Dream-written inner VM
    ↓
inner Dream program
    ↓
raw x86-64 manufactured at runtime
    ↓
processor
    ↓
42
```

## RUN IT ON LINUX

From the Dream Land Linux directory:

```bash
./dreamcc DREAM_IN_DREAM.dc DREAM_IN_DREAM.dvm
./dreamvm DREAM_IN_DREAM.dvm
```

Or use Dream's native C inheritance lane:

```bash
DREAM_HOME=. ./dreamcc --cbuild DREAM_IN_DREAM.dc DREAM_IN_DREAM_NATIVE
./DREAM_IN_DREAM_NATIVE
```

## UEFI

The package contains `uefi/dream.dc`, which is the same source under the filename the
UEFI environment expects. Put it on the writable Dream boot volume, then use the
Dream Land UEFI `load` / `run` workflow.

## WHAT THIS CLAIMS — AND WHAT IT DOES NOT

This is an **honest self-host seed**: Dream implements a second executable Dream
machine and its assembler in Dream.

The current full human-readable Dream lexer/parser still lives in the host compiler.
Moving that lexer/parser into Dream would complete conventional compiler self-hosting,
but it is no longer necessary to prove the essential point: Dream can define a
programmable Dream machine from inside itself and that machine can descend to raw
processor instructions.

The snake has found its tail.

```text
Dream> dream
Dream> dream
Dream> asm
CPU> 42
```

**Bare metal motherfuckers forever.**
