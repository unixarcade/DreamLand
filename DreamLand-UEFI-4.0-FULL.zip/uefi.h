#ifndef DREAM_UEFI_H
#define DREAM_UEFI_H

/* Minimal x86-64 UEFI definitions. Exact-width types; no libc/EDK2 required. */
typedef unsigned char      u8;
typedef unsigned short     u16;
typedef unsigned int       u32;
typedef unsigned long long u64;
typedef signed int         i32;
typedef long long          i64;

#define EFIAPI __attribute__((ms_abi))
typedef u64 EFI_STATUS;
typedef void *EFI_HANDLE;
typedef void *EFI_EVENT;
typedef u16 CHAR16;
typedef u64 UINTN;
typedef u64 EFI_PHYSICAL_ADDRESS;
typedef u64 EFI_VIRTUAL_ADDRESS;
typedef u64 EFI_TPL;
typedef u8 BOOLEAN;

#define EFI_SUCCESS 0
#define EFI_NOT_READY 0x8000000000000006ULL
#define EFI_BUFFER_TOO_SMALL 0x8000000000000005ULL
#define EFI_ERROR(x) (((x) >> 63) != 0)

#define EFI_BLACK       0x00
#define EFI_BLUE        0x01
#define EFI_GREEN       0x02
#define EFI_CYAN        0x03
#define EFI_RED         0x04
#define EFI_MAGENTA     0x05
#define EFI_BROWN       0x06
#define EFI_LIGHTGRAY   0x07
#define EFI_DARKGRAY    0x08
#define EFI_LIGHTBLUE   0x09
#define EFI_LIGHTGREEN  0x0A
#define EFI_LIGHTCYAN   0x0B
#define EFI_LIGHTRED    0x0C
#define EFI_LIGHTMAGENTA 0x0D
#define EFI_YELLOW      0x0E
#define EFI_WHITE       0x0F
#define EFI_TEXT_ATTR(fg,bg) ((fg)|((bg)<<4))

#define AllocateAnyPages 0
#define EfiLoaderCode 1
#define EFI_PAGE_SIZE 4096ULL

#define EFI_FILE_MODE_READ   0x0000000000000001ULL
#define EFI_FILE_MODE_WRITE  0x0000000000000002ULL
#define EFI_FILE_MODE_CREATE 0x8000000000000000ULL

#define SCAN_NULL 0
#define SCAN_UP 1
#define SCAN_DOWN 2
#define SCAN_RIGHT 3
#define SCAN_LEFT 4
#define SCAN_HOME 5
#define SCAN_END 6
#define SCAN_INSERT 7
#define SCAN_DELETE 8
#define SCAN_PAGE_UP 9
#define SCAN_PAGE_DOWN 10
#define SCAN_ESC 23

typedef struct { u32 Data1; u16 Data2; u16 Data3; u8 Data4[8]; } EFI_GUID;
typedef struct { u64 Signature; u32 Revision; u32 HeaderSize; u32 CRC32; u32 Reserved; } EFI_TABLE_HEADER;
typedef struct { u16 ScanCode; CHAR16 UnicodeChar; } EFI_INPUT_KEY;

typedef EFI_STATUS (EFIAPI *EFI_INPUT_RESET)(void*, BOOLEAN);
typedef EFI_STATUS (EFIAPI *EFI_INPUT_READ_KEY)(void*, EFI_INPUT_KEY*);
typedef struct {
 EFI_INPUT_RESET Reset;
 EFI_INPUT_READ_KEY ReadKeyStroke;
 EFI_EVENT WaitForKey;
} EFI_SIMPLE_TEXT_INPUT_PROTOCOL;

typedef EFI_STATUS (EFIAPI *EFI_TEXT_RESET)(void*, BOOLEAN);
typedef EFI_STATUS (EFIAPI *EFI_TEXT_STRING)(void*, CHAR16*);
typedef EFI_STATUS (EFIAPI *EFI_TEXT_TEST_STRING)(void*, CHAR16*);
typedef EFI_STATUS (EFIAPI *EFI_TEXT_QUERY_MODE)(void*, UINTN, UINTN*, UINTN*);
typedef EFI_STATUS (EFIAPI *EFI_TEXT_SET_MODE)(void*, UINTN);
typedef EFI_STATUS (EFIAPI *EFI_TEXT_SET_ATTRIBUTE)(void*, UINTN);
typedef EFI_STATUS (EFIAPI *EFI_TEXT_CLEAR_SCREEN)(void*);
typedef EFI_STATUS (EFIAPI *EFI_TEXT_SET_CURSOR_POSITION)(void*, UINTN, UINTN);
typedef EFI_STATUS (EFIAPI *EFI_TEXT_ENABLE_CURSOR)(void*, BOOLEAN);
typedef struct { i32 MaxMode; i32 Mode; i32 Attribute; i32 CursorColumn; i32 CursorRow; BOOLEAN CursorVisible; } SIMPLE_TEXT_OUTPUT_MODE;

typedef struct {
 EFI_TEXT_RESET Reset;
 EFI_TEXT_STRING OutputString;
 EFI_TEXT_TEST_STRING TestString;
 EFI_TEXT_QUERY_MODE QueryMode;
 EFI_TEXT_SET_MODE SetMode;
 EFI_TEXT_SET_ATTRIBUTE SetAttribute;
 EFI_TEXT_CLEAR_SCREEN ClearScreen;
 EFI_TEXT_SET_CURSOR_POSITION SetCursorPosition;
 EFI_TEXT_ENABLE_CURSOR EnableCursor;
 SIMPLE_TEXT_OUTPUT_MODE *Mode;
} EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL;

typedef EFI_STATUS (EFIAPI *EFI_ALLOCATE_PAGES)(u32,u32,UINTN,EFI_PHYSICAL_ADDRESS*);
typedef EFI_STATUS (EFIAPI *EFI_FREE_PAGES)(EFI_PHYSICAL_ADDRESS,UINTN);
typedef EFI_STATUS (EFIAPI *EFI_WAIT_FOR_EVENT)(UINTN,EFI_EVENT*,UINTN*);
typedef EFI_STATUS (EFIAPI *EFI_HANDLE_PROTOCOL)(EFI_HANDLE,EFI_GUID*,void**);
typedef EFI_STATUS (EFIAPI *EFI_STALL)(UINTN);

typedef struct {
 EFI_TABLE_HEADER Hdr;
 void *RaiseTPL;
 void *RestoreTPL;
 EFI_ALLOCATE_PAGES AllocatePages;
 EFI_FREE_PAGES FreePages;
 void *GetMemoryMap;
 void *AllocatePool;
 void *FreePool;
 void *CreateEvent;
 void *SetTimer;
 EFI_WAIT_FOR_EVENT WaitForEvent;
 void *SignalEvent;
 void *CloseEvent;
 void *CheckEvent;
 void *InstallProtocolInterface;
 void *ReinstallProtocolInterface;
 void *UninstallProtocolInterface;
 EFI_HANDLE_PROTOCOL HandleProtocol;
 void *Reserved;
 void *RegisterProtocolNotify;
 void *LocateHandle;
 void *LocateDevicePath;
 void *InstallConfigurationTable;
 void *LoadImage;
 void *StartImage;
 void *Exit;
 void *UnloadImage;
 void *ExitBootServices;
 void *GetNextMonotonicCount;
 EFI_STALL Stall;
 void *SetWatchdogTimer;
 void *ConnectController;
 void *DisconnectController;
 void *OpenProtocol;
 void *CloseProtocol;
 void *OpenProtocolInformation;
 void *ProtocolsPerHandle;
 void *LocateHandleBuffer;
 void *LocateProtocol;
 void *InstallMultipleProtocolInterfaces;
 void *UninstallMultipleProtocolInterfaces;
 void *CalculateCrc32;
 void *CopyMem;
 void *SetMem;
 void *CreateEventEx;
} EFI_BOOT_SERVICES;

typedef struct EFI_FILE_PROTOCOL EFI_FILE_PROTOCOL;
typedef EFI_STATUS (EFIAPI *EFI_FILE_OPEN)(EFI_FILE_PROTOCOL*,EFI_FILE_PROTOCOL**,CHAR16*,u64,u64);
typedef EFI_STATUS (EFIAPI *EFI_FILE_CLOSE)(EFI_FILE_PROTOCOL*);
typedef EFI_STATUS (EFIAPI *EFI_FILE_DELETE)(EFI_FILE_PROTOCOL*);
typedef EFI_STATUS (EFIAPI *EFI_FILE_READ)(EFI_FILE_PROTOCOL*,UINTN*,void*);
typedef EFI_STATUS (EFIAPI *EFI_FILE_WRITE)(EFI_FILE_PROTOCOL*,UINTN*,void*);
typedef EFI_STATUS (EFIAPI *EFI_FILE_GET_POSITION)(EFI_FILE_PROTOCOL*,u64*);
typedef EFI_STATUS (EFIAPI *EFI_FILE_SET_POSITION)(EFI_FILE_PROTOCOL*,u64);
typedef EFI_STATUS (EFIAPI *EFI_FILE_GET_INFO)(EFI_FILE_PROTOCOL*,EFI_GUID*,UINTN*,void*);
typedef EFI_STATUS (EFIAPI *EFI_FILE_SET_INFO)(EFI_FILE_PROTOCOL*,EFI_GUID*,UINTN,void*);
typedef EFI_STATUS (EFIAPI *EFI_FILE_FLUSH)(EFI_FILE_PROTOCOL*);
struct EFI_FILE_PROTOCOL {
 u64 Revision;
 EFI_FILE_OPEN Open;
 EFI_FILE_CLOSE Close;
 EFI_FILE_DELETE Delete;
 EFI_FILE_READ Read;
 EFI_FILE_WRITE Write;
 EFI_FILE_GET_POSITION GetPosition;
 EFI_FILE_SET_POSITION SetPosition;
 EFI_FILE_GET_INFO GetInfo;
 EFI_FILE_SET_INFO SetInfo;
 EFI_FILE_FLUSH Flush;
 void *OpenEx; void *ReadEx; void *WriteEx; void *FlushEx;
};

typedef struct EFI_SIMPLE_FILE_SYSTEM_PROTOCOL EFI_SIMPLE_FILE_SYSTEM_PROTOCOL;
typedef EFI_STATUS (EFIAPI *EFI_OPEN_VOLUME)(EFI_SIMPLE_FILE_SYSTEM_PROTOCOL*, EFI_FILE_PROTOCOL**);
struct EFI_SIMPLE_FILE_SYSTEM_PROTOCOL { u64 Revision; EFI_OPEN_VOLUME OpenVolume; };

typedef struct {
 u32 Revision;
 EFI_HANDLE ParentHandle;
 void *SystemTable;
 EFI_HANDLE DeviceHandle;
 void *FilePath;
 void *Reserved;
 u32 LoadOptionsSize;
 void *LoadOptions;
 void *ImageBase;
 u64 ImageSize;
 u32 ImageCodeType;
 u32 ImageDataType;
 void *Unload;
} EFI_LOADED_IMAGE_PROTOCOL;

typedef struct {
 EFI_TABLE_HEADER Hdr;
 CHAR16 *FirmwareVendor;
 u32 FirmwareRevision;
 EFI_HANDLE ConsoleInHandle;
 EFI_SIMPLE_TEXT_INPUT_PROTOCOL *ConIn;
 EFI_HANDLE ConsoleOutHandle;
 EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *ConOut;
 EFI_HANDLE StandardErrorHandle;
 EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *StdErr;
 void *RuntimeServices;
 EFI_BOOT_SERVICES *BootServices;
 u64 NumberOfTableEntries;
 void *ConfigurationTable;
} EFI_SYSTEM_TABLE;

#endif
