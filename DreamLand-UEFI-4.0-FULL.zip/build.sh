#!/usr/bin/env bash
set -euo pipefail
make clean
make CC=clang LD=lld-link
mkdir -p esp/EFI/BOOT
cp BOOTX64.EFI esp/EFI/BOOT/BOOTX64.EFI
file BOOTX64.EFI
