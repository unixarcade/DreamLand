#include "uefi.h"
#include "dream3_core.h"
#include "dream_cbridge.h"
#include "dream_metal.h"

/* Compiler helpers kept local so the PE/COFF target cannot smuggle in a CRT. */
void *memcpy(void*d,const void*s,unsigned long long n){u8*dd=(u8*)d;const u8*ss=(const u8*)s;for(unsigned long long i=0;i<n;i++)dd[i]=ss[i];return d;}
void *memset(void*d,int v,unsigned long long n){u8*dd=(u8*)d;for(unsigned long long i=0;i<n;i++)dd[i]=(u8)v;return d;}

/* DREAM LAND UEFI 4.0
   Dream 3.5 compiler/VM returned to firmware: no libc, no CRT, no OS. */

static EFI_HANDLE gImage;
static EFI_SYSTEM_TABLE *gST;
static EFI_BOOT_SERVICES *gBS;
static EFI_FILE_PROTOCOL *gRoot;
static UINTN gCols=80,gRows=25;
static int gLines=1,gHud=1,gSparkle=1,gExit=0;
static char gSource[32768];
static int gSourceN=0;
static D3Program gProg;
static DCB gBridge;
static d_u8 gMetal[DM_MAX],gCoff[DM_MAX+128];

/* ---------- tiny text ---------- */
static void attr(UINTN a){ gST->ConOut->SetAttribute(gST->ConOut,a); }
static void pos(UINTN x,UINTN y){ gST->ConOut->SetCursorPosition(gST->ConOut,x,y); }
static void clear_screen(void){ gST->ConOut->ClearScreen(gST->ConOut); }
static int slen(const char*s){int n=0;while(s&&s[n])n++;return n;}
static int seq(const char*a,const char*b){int i=0;for(;;i++){if(a[i]!=b[i])return 0;if(!a[i])return 1;}}
static int prefix(const char*s,const char*p){int i=0;while(p[i]){if(s[i]!=p[i])return 0;i++;}return 1;}
static int contains_ci(const char*s,const char*q){int n=slen(s),m=slen(q);if(!m)return 1;for(int i=0;i<=n-m;i++){int ok=1;for(int j=0;j<m;j++){char a=s[i+j],b=q[j];if(a>='A'&&a<='Z')a+=32;if(b>='A'&&b<='Z')b+=32;if(a!=b){ok=0;break;}}if(ok)return 1;}return 0;}
static void cpy(char*d,const char*s,int cap){int i=0;if(cap<1)return;while(s&&s[i]&&i<cap-1){d[i]=s[i];i++;}d[i]=0;}
static void cat(char*d,int*dn,int cap,const char*s){for(int i=0;s&&s[i]&&*dn<cap-1;i++)d[(*dn)++]=s[i];d[*dn]=0;}

static void raw_ascii(const char*s){
 CHAR16 w[384];int n=0;
 while(*s){
  char c=*s++;
  if(c=='\n'){ if(n){w[n]=0;gST->ConOut->OutputString(gST->ConOut,w);n=0;} CHAR16 nl[3]={'\r','\n',0};gST->ConOut->OutputString(gST->ConOut,nl); continue; }
  if(n>=382){w[n]=0;gST->ConOut->OutputString(gST->ConOut,w);n=0;}
  w[n++]=(u8)c;
 }
 if(n){w[n]=0;gST->ConOut->OutputString(gST->ConOut,w);}
}
static void out(const char*s){
 /* tiny ANSI SGR bridge: ESC[0m, 30..37, 90..97. */
 while(*s){
  if((u8)s[0]==27 && s[1]=='['){int i=2,n=0,have=0;while(s[i]>='0'&&s[i]<='9'){n=n*10+(s[i]-'0');have=1;i++;}if(s[i]=='m'){
    UINTN fg=EFI_LIGHTGREEN;
    if(!have||n==0)fg=EFI_LIGHTGREEN;
    else if(n>=30&&n<=37)fg=(UINTN)(n-30);
    else if(n>=90&&n<=97)fg=(UINTN)(8+n-90);
    attr(EFI_TEXT_ATTR(fg,EFI_BLACK));s+=i+1;continue;
  }}
  char b[2]={*s++,0};raw_ascii(b);
 }
}
static void line(const char*s){out(s);out("\n");}
static void out_i(i64 v){char b[48];d3_i64str(v,b);out(b);}

/* ---------- UEFI file system ---------- */
static EFI_GUID LOADED_IMAGE_GUID={0x5B1B31A1,0x9562,0x11d2,{0x8E,0x3F,0x00,0xA0,0xC9,0x69,0x72,0x3B}};
static EFI_GUID SIMPLE_FS_GUID={0x964e5b22,0x6459,0x11d2,{0x8e,0x39,0x00,0xa0,0xc9,0x69,0x72,0x3b}};
static void to16(const char*s,CHAR16*w,int cap){int i=0;while(s[i]&&i<cap-1){w[i]=(u8)s[i];i++;}w[i]=0;}
static void fs_init(void){EFI_LOADED_IMAGE_PROTOCOL*li=0;EFI_SIMPLE_FILE_SYSTEM_PROTOCOL*fs=0;if(EFI_ERROR(gBS->HandleProtocol(gImage,&LOADED_IMAGE_GUID,(void**)&li))||!li)return;if(EFI_ERROR(gBS->HandleProtocol(li->DeviceHandle,&SIMPLE_FS_GUID,(void**)&fs))||!fs)return;fs->OpenVolume(fs,&gRoot);}
static EFI_FILE_PROTOCOL* fs_create(const char*name){if(!gRoot)return 0;CHAR16 w[96];to16(name,w,96);EFI_FILE_PROTOCOL*f=0;if(!EFI_ERROR(gRoot->Open(gRoot,&f,w,EFI_FILE_MODE_READ|EFI_FILE_MODE_WRITE,0))&&f){f->Delete(f);f=0;}if(EFI_ERROR(gRoot->Open(gRoot,&f,w,EFI_FILE_MODE_READ|EFI_FILE_MODE_WRITE|EFI_FILE_MODE_CREATE,0)))return 0;return f;}
static int fs_write(const char*name,const void*data,UINTN n){EFI_FILE_PROTOCOL*f=fs_create(name);if(!f)return 0;UINTN z=n;EFI_STATUS st=f->Write(f,&z,(void*)data);f->Flush(f);f->Close(f);return !EFI_ERROR(st)&&z==n;}
static int fs_read(const char*name,void*data,UINTN cap,UINTN*got){if(!gRoot)return 0;CHAR16 w[96];to16(name,w,96);EFI_FILE_PROTOCOL*f=0;if(EFI_ERROR(gRoot->Open(gRoot,&f,w,EFI_FILE_MODE_READ,0))||!f)return 0;UINTN n=cap;EFI_STATUS st=f->Read(f,&n,data);f->Close(f);if(got)*got=n;return !EFI_ERROR(st);}

/* ---------- executable page host ---------- */
typedef struct{void*p;UINTN pages;} Allocation;
static Allocation gAlloc[64];
static void* host_alloc(void*ctx,d_u64 n){(void)ctx;UINTN pages=(UINTN)((n+EFI_PAGE_SIZE-1)/EFI_PAGE_SIZE);if(!pages)pages=1;EFI_PHYSICAL_ADDRESS a=0;if(EFI_ERROR(gBS->AllocatePages(AllocateAnyPages,EfiLoaderCode,pages,&a)))return 0;for(int i=0;i<64;i++)if(!gAlloc[i].p){gAlloc[i].p=(void*)(UINTN)a;gAlloc[i].pages=pages;return gAlloc[i].p;}gBS->FreePages(a,pages);return 0;}
static void host_free(void*ctx,void*p){(void)ctx;if(!p)return;for(int i=0;i<64;i++)if(gAlloc[i].p==p){gBS->FreePages((EFI_PHYSICAL_ADDRESS)(UINTN)p,gAlloc[i].pages);gAlloc[i].p=0;gAlloc[i].pages=0;return;}}
static void host_out(void*ctx,const char*s){(void)ctx;out(s);}static void host_putc(void*ctx,char c){(void)ctx;char b[2]={c,0};out(b);}

static d_u64 EFIAPI uefi_clear(void){clear_screen();return 0;}
static d_u64 EFIAPI uefi_stall(d_u64 us){gBS->Stall((UINTN)us);return 0;}
static d_u64 EFIAPI uefi_attr(d_u64 a){attr((UINTN)a);return 0;}
static d_u64 EFIAPI uefi_print(d_u64 p){out((const char*)(UINTN)p);return 0;}
static d_u64 host_api(void*ctx,const char*dll,const char*name){(void)ctx;(void)dll;if(seq(name,"st"))return (d_u64)(UINTN)gST;if(seq(name,"bs"))return (d_u64)(UINTN)gBS;if(seq(name,"rs"))return (d_u64)(UINTN)gST->RuntimeServices;if(seq(name,"conout"))return (d_u64)(UINTN)gST->ConOut;if(seq(name,"conin"))return (d_u64)(UINTN)gST->ConIn;if(seq(name,"clear"))return (d_u64)(UINTN)&uefi_clear;if(seq(name,"stall"))return (d_u64)(UINTN)&uefi_stall;if(seq(name,"attr"))return (d_u64)(UINTN)&uefi_attr;if(seq(name,"print"))return (d_u64)(UINTN)&uefi_print;return 0;}
static D3Host gHost={host_out,host_putc,host_alloc,host_free,host_api,0};

/* ---------- clean 53rd-century firmware UI ---------- */
static void cell(UINTN x,UINTN y,char c,UINTN color){pos(x,y);attr(EFI_TEXT_ATTR(color,EFI_BLACK));char b[2]={c,0};raw_ascii(b);}
static void checker_frame(void){for(UINTN x=0;x<gCols;x++){UINTN c=((x/2)&1)?EFI_WHITE:EFI_LIGHTGREEN;cell(x,0,'=',c);if(gRows>1)cell(x,gRows-1,'=',c);}for(UINTN y=1;y+1<gRows;y++){UINTN c=((y/2)&1)?EFI_WHITE:EFI_LIGHTGREEN;cell(0,y,'|',c);if(gCols>1)cell(gCols-1,y,'|',c);}}
static void ui_home(void){clear_screen();checker_frame();attr(EFI_TEXT_ATTR(EFI_WHITE,EFI_BLACK));pos(3,2);raw_ascii("DREAM LAND UEFI 4.0");if(gHud){attr(EFI_TEXT_ATTR(EFI_LIGHTGREEN,EFI_BLACK));raw_ascii("  DRM3:READY // METAL:READY // ASM:GATE-OPEN // UEFI:NATIVE");}if(gSparkle){UINTN xs[4]={gCols/4,gCols/2,(gCols*3)/4,gCols-8};for(int i=0;i<4;i++)if(xs[i]<gCols-2)cell(xs[i],2,'+',i==1?EFI_WHITE:EFI_GREEN);}/* row 3 intentionally blank */
 UINTN y=4,left=3,right=gCols>6?gCols-4:3;for(UINTN x=left;x<=right;x++){UINTN c=((x-left)/2)&1?EFI_WHITE:EFI_LIGHTGREEN;cell(x,y,'-',c);cell(x,y+2,'-',c);}cell(left,y+1,'|',EFI_WHITE);cell(right,y+1,'|',EFI_WHITE);attr(EFI_TEXT_ATTR(EFI_LIGHTGREEN,EFI_BLACK));pos(left+2,y+1);raw_ascii("Dream> ");attr(EFI_TEXT_ATTR(EFI_WHITE,EFI_BLACK));gST->ConOut->EnableCursor(gST->ConOut,1);}
static void output_begin(void){/* command output starts below jewel */pos(3,8);attr(EFI_TEXT_ATTR(EFI_LIGHTGREEN,EFI_BLACK));}
static void wait_key(void){line("\n[press any key]");EFI_EVENT e=gST->ConIn->WaitForKey;UINTN ix=0;gBS->WaitForEvent(1,&e,&ix);EFI_INPUT_KEY k;gST->ConIn->ReadKeyStroke(gST->ConIn,&k);}

/* ---------- keyboard ---------- */
static int read_line_at(char*b,int cap,UINTN x,UINTN y){int n=0;b[0]=0;pos(x,y);gST->ConOut->EnableCursor(gST->ConOut,1);for(;;){attr(EFI_TEXT_ATTR(EFI_WHITE,EFI_BLACK));EFI_EVENT e=gST->ConIn->WaitForKey;UINTN ix=0;gBS->WaitForEvent(1,&e,&ix);EFI_INPUT_KEY k;if(EFI_ERROR(gST->ConIn->ReadKeyStroke(gST->ConIn,&k)))continue;if(k.ScanCode==SCAN_ESC)return -1;u16 c=k.UnicodeChar;if(c=='\r'){b[n]=0;return n;}if(c==8){if(n>0){n--;b[n]=0;UINTN cx=x+(UINTN)n;pos(cx,y);raw_ascii(" ");pos(cx,y);}continue;}if(c>=32&&c<127&&n<cap-1){b[n++]=(char)c;b[n]=0;attr(EFI_TEXT_ATTR(EFI_LIGHTGREEN,EFI_BLACK));char q[2]={(char)c,0};raw_ascii(q);}}}

/* ---------- manuals ---------- */
static const char* TOPICS[]={"list","search","man","example","greetz","edit","show","run","do","build","save","load","new","clear","lines","sparkle","calm","hud","lang","ops","asm","macro","ansi","metal","obj","cgen","cbridge","api","native","peek","poke","alloc","about","exit",0};
static void list_topics(void){line("COMMANDS // UEFI DREAM");for(int i=0;TOPICS[i];i++){out(TOPICS[i]);out((i%5==4)?"\n":"   ");}line("\nman TOPIC // two-line explainer    search TERM // find names");}
static void greetz(void){line("GREETZ // DREAM LAND");line("MADE BY LUMINOSITY + GPTEUS THE ELECTRIC SPRITE");line("SUPPORT // CASH APP $UNIXARCADE");line("");line("LIVEJOURNAL // https://luminosity.livejournal.com");line("FORGE AI OS // https://luminosity.gumroad.com/l/fyosxi");line("GUMROAD // https://luminosity.gumroad.com");line("GUMROAD PRODUCTS // https://gumroad.com/products");line("GITHUB // https://github.com/unixarcade");line("GOODREADS // https://www.goodreads.com/review/list/1550470-matthew-kowalski?ref=nav_mybooks&shelf=books-i-have-written");}
static void example(void){line("macro GREEN = \"\\e[92m\";");line("macro RESET = \"\\e[0m\";");line("var x = 0;");line("loop:");line("print(GREEN, x, \"  \", RESET);");line("x = x + 1;");line("if x < 8 goto loop;");line("var answer = asm { B8 2A 00 00 00 C3 };");line("println(answer);");line("halt;");}
static void man(const char*t){if(!t||!*t){list_topics();return;}if(seq(t,"greetz")||seq(t,"support")){greetz();return;}if(seq(t,"example")){example();return;}
 if(seq(t,"asm"))line("asm { HEX } // execute raw x64 from firmware-allocated loader-code pages; RAX becomes the expression result.\nUse it when Dream should disappear and the CPU instruction stream should be the language.");
 else if(seq(t,"macro"))line("macro NAME = number-or-string; // compile-time Dream constant with zero runtime lookup.\nUse it to compress repeated constants, addresses, ANSI styles, and tiny configuration vocabularies.");
 else if(seq(t,"ansi"))line("Dream strings understand \\e as ESC; common ANSI SGR colors are translated into UEFI text attributes.\nExample: macro G=\"\\e[92m\"; print(G,\"green\",\"\\e[0m\");");
 else if(seq(t,"api"))line("api(\"uefi\",\"name\") // resolve firmware gates: st, bs, rs, conout, conin, clear, stall, attr, print.\nPointers such as st/bs expose the firmware itself; wrappers can be passed straight to native().");
 else if(seq(t,"native"))line("native(fn,a..f) // call a Win64/UEFI ABI function pointer with up to six 64-bit arguments.\nPair with api(), raw addresses, or your own asm to cross directly into firmware or machine code.");
 else if(seq(t,"metal"))line("metal // extract asm plus byte/word/dword/qword/align/pad into dream.bin on the boot volume.\nThis is the flat-binary lane for loaders, kernels, firmware payloads, ROMs, and other raw images.");
 else if(seq(t,"obj"))line("obj // emit the metal payload as x86-64 COFF dream.obj exporting dream_entry.\nTake it back to LLD after boot to link EFI, PE/native, or driver artifacts.");
 else if(seq(t,"cgen"))line("cgen // generate dream_native.c onto the boot volume from CBridge directives plus compiled Dream.\nFirmware cannot run GCC itself; compile that generated file later with the hosted Dream/GCC/Clang lane.");
 else if(seq(t,"cbridge"))line("cimport/link/cflag/c blocks remain source-compatible and cgen can carry them back to the hosted toolchain.\nextern c \"uefi\" declarations can also resolve firmware wrappers immediately through Dream api/native.");
 else if(seq(t,"edit"))line("edit // append source lines in a firmware-native editor; .done returns, .run runs, .show displays, .undo removes last line.\nThe default source is empty: Dream boots into a machine, not a tutorial.");
 else if(seq(t,"do"))line("do CODE // compile and run one line of Dream immediately without touching the saved source buffer.\nIt is the tiny firmware REPL lane: do println(6*7); or do println(asm { B8 2A 00 00 00 C3 });");
 else if(seq(t,"run"))line("run // CBridge-prepare, compile once into DRM3 bytecode, then execute in the firmware VM.\nExpressions are opcodes at runtime; raw memory, UEFI API gates, and asm remain available.");
 else if(seq(t,"build"))line("build // compile the current Dream source and write dream.dvm onto the boot volume.\nThe bytecode image can later be run by the hosted dreamvm or another Dream runtime.");
 else if(seq(t,"save")||seq(t,"load"))line("save/load // write or read dream.dc beside the UEFI application on the boot filesystem.\nThis turns the firmware shell into a persistent tiny development environment instead of a one-shot demo.");
 else if(seq(t,"peek")||seq(t,"poke"))line("peek8/16/32/64(addr) and poke8/16/32/64(addr,val) // direct physical-address-space memory access.\nThere is no sandbox here; this is intentionally the metal-facing end of Dream.");
 else if(seq(t,"alloc"))line("alloc(bytes) // allocate UEFI EfiLoaderCode pages; free(ptr) releases them through Boot Services.\nLoader-code pages also make hosted asm blocks executable without depending on an operating system allocator.");
 else if(seq(t,"lang")){line("DREAM C UEFI // var/int/ptr, expressions, labels/goto, if goto, call/return, print/println, macro, raw memory, api/native, asm.");line("Operators: + - * / % << >> & | ^ ~ ! && || == != < <= > >= plus %% ?= <-> ->> @>.");}
 else if(seq(t,"clear"))line("clear // repaint canonical Dream Land firmware HOME: checker frame, one telemetry line, one blank line, Dream> jewel.\nYour source buffer survives; only transient command output disappears.");
 else if(seq(t,"calm"))line("calm // silence optional firmware flair immediately while retaining the checker frame and all functionality.\nUEFI Dream avoids animation timers entirely; calm simply removes the sparse static sparkle glyphs.");
 else if(seq(t,"about"))line("DREAM LAND UEFI 4.0 // Dream 3.5 compiler + DRM3 VM returned to bare firmware.\nNo libc, CRT, Win32, or operating system is underneath this environment.");
 else line("NO MAN ENTRY // use list or search TERM");}

/* ---------- source/editor ---------- */
static void show_source(void){if(!gSourceN){line("[source is empty] // man example");return;}int ln=1,p=0;while(p<gSourceN){if(gLines){out_i(ln++);out(" | ");}char b[512];int n=0;while(p<gSourceN&&gSource[p]!='\n'&&n<510)b[n++]=gSource[p++];if(p<gSourceN&&gSource[p]=='\n')p++;b[n]=0;line(b);}}
static void append_line(const char*s){int n=slen(s);if(gSourceN+n+1>=(int)sizeof(gSource))return;for(int i=0;i<n;i++)gSource[gSourceN++]=s[i];gSource[gSourceN++]='\n';gSource[gSourceN]=0;}
static void undo_line(void){if(gSourceN<=0)return;if(gSourceN&&gSource[gSourceN-1]=='\n')gSourceN--;while(gSourceN>0&&gSource[gSourceN-1]!='\n')gSourceN--;gSource[gSourceN]=0;}
static int source_lines(void){int n=1;for(int i=0;i<gSourceN;i++)if(gSource[i]=='\n')n++;return n;}

static int compile_source(const char*src){if(!dcb_prepare(&gBridge,src)){line("CBRIDGE ERROR");line(gBridge.error);return 0;}if(!d3_compile(&gProg,gBridge.dream)){out("COMPILE ERROR // line ");out_i(gProg.error_line);out(" // ");line(gProg.error);return 0;}out("COMPILE OK // ");out_i(gProg.ncode);out(" ops // ");out_i(gProg.nvars);line(" vars");return 1;}
static void run_source(const char*src){if(!compile_source(src))return;D3VM vm;if(!d3_run(&gProg,&gHost,&vm,100000000)){out("VM FAULT // ");line(vm.error_text);}else line("RUN COMPLETE");}
static void editor(void){clear_screen();attr(EFI_TEXT_ATTR(EFI_WHITE,EFI_BLACK));line("DREAM EDIT // append mode // .done .run .show .undo .new");attr(EFI_TEXT_ATTR(EFI_LIGHTGREEN,EFI_BLACK));if(gSourceN)show_source();for(;;){char b[512];if(gLines){out_i(source_lines());out(" > ");}else out("> ");UINTN x=gST->ConOut->Mode?(UINTN)gST->ConOut->Mode->CursorColumn:3,y=gST->ConOut->Mode?(UINTN)gST->ConOut->Mode->CursorRow:2;int n=read_line_at(b,512,x,y);line("");if(n<0||seq(b,".done"))break;if(seq(b,".run")){run_source(gSource);line("");continue;}if(seq(b,".show")){show_source();continue;}if(seq(b,".undo")){undo_line();line("UNDO");continue;}if(seq(b,".new")){gSourceN=0;gSource[0]=0;line("NEW");continue;}append_line(b);}ui_home();}

/* ---------- build lanes ---------- */
static void save_source(void){if(fs_write("dream.dc",gSource,(UINTN)gSourceN))line("SAVE OK // dream.dc");else line("SAVE FAILED // boot filesystem unavailable");}
static void load_source(void){UINTN n=0;if(fs_read("dream.dc",gSource,sizeof(gSource)-1,&n)){gSourceN=(int)n;gSource[gSourceN]=0;line("LOAD OK // dream.dc");}else line("LOAD FAILED // no dream.dc");}
static void build_dvm(void){if(!compile_source(gSource))return;EFI_FILE_PROTOCOL*f=fs_create("dream.dvm");if(!f){line("BUILD FAILED // filesystem");return;}D3Head h={{'D','R','M','3'},3,(d_u32)gProg.ncode,(d_u32)gProg.nvars,0};UINTN n=sizeof(h);f->Write(f,&n,&h);n=(UINTN)(gProg.ncode*(int)sizeof(D3Ins));f->Write(f,&n,gProg.code);f->Flush(f);f->Close(f);line("BUILD OK // dream.dvm");}
static void metal_emit(int coff){char er[160];int n=0;if(!dm_extract(gSource,gMetal,DM_MAX,&n,er,160)){line(er);return;}const void*p=gMetal;int bytes=n;const char*fn="dream.bin";if(coff){bytes=dm_coff(gMetal,n,gCoff,DM_MAX+128);p=gCoff;fn="dream.obj";if(!bytes){line("COFF ERROR");return;}}if(fs_write(fn,p,(UINTN)bytes)){out(coff?"OBJ OK // ":"METAL OK // ");out(fn);out(" // ");out_i(bytes);line(" bytes");}else line("WRITE FAILED // filesystem");}
static void cgen(void){if(!dcb_prepare(&gBridge,gSource)){line(gBridge.error);return;}if(!d3_compile(&gProg,gBridge.dream)){line(gProg.error);return;}int cap=8*1024*1024;char*b=(char*)host_alloc(0,(d_u64)cap);if(!b){line("CGEN // allocation failed");return;}int n=dcb_generate_c(&gBridge,&gProg,b,cap);if(n&&fs_write("dream_native.c",b,(UINTN)n))line("CGEN OK // dream_native.c // compile later with GCC/Clang");else line("CGEN FAILED");host_free(0,b);}

/* ---------- command shell ---------- */
static void command(char*c){output_begin();if(!*c)return;
 if(seq(c,"list")||seq(c,"help")){list_topics();return;}if(prefix(c,"search ")){const char*q=c+7;int hit=0;for(int i=0;TOPICS[i];i++)if(contains_ci(TOPICS[i],q)){line(TOPICS[i]);hit++;}if(!hit)line("NO MATCHES");return;}if(seq(c,"man")){man(0);return;}if(prefix(c,"man ")){man(c+4);return;}if(seq(c,"greetz")||seq(c,"support")){greetz();return;}if(seq(c,"example")){example();return;}if(seq(c,"edit")){editor();return;}if(seq(c,"show")){show_source();return;}if(seq(c,"run")){run_source(gSource);return;}if(prefix(c,"do ")){run_source(c+3);return;}if(seq(c,"save")){save_source();return;}if(seq(c,"load")){load_source();return;}if(seq(c,"build")){build_dvm();return;}if(seq(c,"metal")){metal_emit(0);return;}if(seq(c,"obj")){metal_emit(1);return;}if(seq(c,"cgen")){cgen();return;}if(seq(c,"new")){gSourceN=0;gSource[0]=0;line("NEW // source empty");return;}if(seq(c,"lines")){gLines=!gLines;line(gLines?"LINES // ON":"LINES // OFF");return;}if(seq(c,"sparkle")){gSparkle=!gSparkle;line(gSparkle?"SPARKLE // ON":"SPARKLE // OFF");return;}if(seq(c,"calm")){gSparkle=0;line("CALM // FLAIR OFF");return;}if(seq(c,"hud")){gHud=!gHud;line(gHud?"HUD // ON":"HUD // OFF");return;}if(seq(c,"clear")||seq(c,"home")){ui_home();return;}if(seq(c,"lang")){man("lang");return;}if(seq(c,"ops")){line("%% WEAVE | ?= MATCH | <-> RESONANCE/XOR | ->> FLOW | @> MATERIALIZE64");return;}if(seq(c,"asm")){man("asm");return;}if(seq(c,"about")){man("about");return;}if(seq(c,"exit")){gExit=1;return;}line("UNKNOWN DREAM // list | search TERM | man TOPIC");}

EFI_STATUS EFIAPI efi_main(EFI_HANDLE ImageHandle, EFI_SYSTEM_TABLE *SystemTable){gImage=ImageHandle;gST=SystemTable;gBS=SystemTable->BootServices;gSource[0]=0;gSourceN=0;fs_init();if(gST->ConOut->Mode&&gST->ConOut->QueryMode){UINTN c=0,r=0;if(!EFI_ERROR(gST->ConOut->QueryMode(gST->ConOut,(UINTN)gST->ConOut->Mode->Mode,&c,&r))&&c>=40&&r>=15){gCols=c;gRows=r;}}ui_home();
 while(!gExit){char cmd[512];UINTN y=5;/* prompt text begins after the seven-character Dream> label */int n=read_line_at(cmd,512,12,y);if(n<0){ui_home();continue;}command(cmd);if(gExit)break;if(!seq(cmd,"clear")&&!seq(cmd,"home")&&!seq(cmd,"edit")){wait_key();ui_home();}}
 clear_screen();attr(EFI_TEXT_ATTR(EFI_LIGHTGREEN,EFI_BLACK));line("Dream Land returning to firmware.");return EFI_SUCCESS;}
