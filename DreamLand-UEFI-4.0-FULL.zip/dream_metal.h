#ifndef DREAM_METAL_H
#define DREAM_METAL_H
#include "dream3_core.h"
#define DM_MAX 262144
static int dm_hex(char c){if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return -1;}
static int dm_space(char c){return c==' '||c=='\t'||c=='\r'||c=='\n'||c==',';}
static int dm_wordat(const char*s,int p,const char*w){int i=0;while(w[i]&&s[p+i]==w[i])i++;return !w[i]&&!((s[p+i]>='A'&&s[p+i]<='Z')||(s[p+i]>='a'&&s[p+i]<='z')||(s[p+i]>='0'&&s[p+i]<='9')||s[p+i]=='_');}
static d_u64 dm_num(const char*s,int*p){while(dm_space(s[*p]))(*p)++;int base=10;if(s[*p]=='0'&&(s[*p+1]=='x'||s[*p+1]=='X')){base=16;*p+=2;}d_u64 v=0;for(;;){int h=dm_hex(s[*p]);if(h<0||h>=base)break;v=v*base+(d_u64)h;(*p)++;}return v;}
static int dm_emit(d_u8*out,int*on,int max,d_u64 v,int bytes){if(*on+bytes>max)return 0;for(int i=0;i<bytes;i++)out[(*on)++]=(d_u8)(v>>(8*i));return 1;}
static int dm_extract(const char*s,d_u8*out,int max,int*on,char*err,int errn){int p=0,n=0;err[0]=0;while(s[p]){
  if(s[p]=='/'&&s[p+1]=='/'){while(s[p]&&s[p]!='\n')p++;continue;}
  if(s[p]=='/'&&s[p+1]=='*'){p+=2;while(s[p]&&!(s[p]=='*'&&s[p+1]=='/'))p++;if(s[p])p+=2;continue;}
  if(dm_wordat(s,p,"asm")){p+=3;while(dm_space(s[p]))p++;if(s[p]!='{'){d3_copy(err,"metal: asm requires { hex bytes }",errn);return 0;}p++;while(s[p]&&s[p]!='}'){
    if(dm_space(s[p])){p++;continue;}if(s[p]=='/'&&s[p+1]=='/'){while(s[p]&&s[p]!='\n')p++;continue;}
    int a=dm_hex(s[p]),b=dm_hex(s[p+1]);if(a<0||b<0){d3_copy(err,"metal: expected two hex digits",errn);return 0;}if(n>=max){d3_copy(err,"metal: image too large",errn);return 0;}out[n++]=(d_u8)((a<<4)|b);p+=2;
   }if(s[p]!='}'){d3_copy(err,"metal: unclosed asm block",errn);return 0;}p++;continue;}
  if(dm_wordat(s,p,"byte")||dm_wordat(s,p,"word")||dm_wordat(s,p,"dword")||dm_wordat(s,p,"qword")){int bytes=1;if(dm_wordat(s,p,"word"))bytes=2;else if(dm_wordat(s,p,"dword"))bytes=4;else if(dm_wordat(s,p,"qword"))bytes=8;while(s[p]&&s[p]!=' '&&s[p]!='\t')p++;d_u64 v=dm_num(s,&p);if(!dm_emit(out,&n,max,v,bytes)){d3_copy(err,"metal: image too large",errn);return 0;}while(s[p]&&s[p]!='\n'&&s[p]!=';')p++;if(s[p])p++;continue;}
  if(dm_wordat(s,p,"pad")){p+=3;d_u64 to=dm_num(s,&p),fill=0;if(s[p]&&s[p]!='\n'&&s[p]!=';')fill=dm_num(s,&p);if(to>(d_u64)max||to<(d_u64)n){d3_copy(err,"metal: bad pad target",errn);return 0;}while((d_u64)n<to)out[n++]=(d_u8)fill;while(s[p]&&s[p]!='\n'&&s[p]!=';')p++;if(s[p])p++;continue;}
  if(dm_wordat(s,p,"align")){p+=5;d_u64 a=dm_num(s,&p);if(!a)a=1;while((d_u64)n%a){if(n>=max){d3_copy(err,"metal: image too large",errn);return 0;}out[n++]=0;}while(s[p]&&s[p]!='\n'&&s[p]!=';')p++;if(s[p])p++;continue;}
  p++;
 }*on=n;return 1;}
static void dm_u16(d_u8*b,int*p,d_u16 v){b[(*p)++]=(d_u8)v;b[(*p)++]=(d_u8)(v>>8);}static void dm_u32(d_u8*b,int*p,d_u32 v){for(int i=0;i<4;i++)b[(*p)++]=(d_u8)(v>>(8*i));}
static int dm_coff(const d_u8*code,int n,d_u8*out,int max){const char*sym="dream_entry";int sl=12;int need=20+40+n+18+4+sl;if(need>max)return 0;for(int i=0;i<need;i++)out[i]=0;int p=0;
 dm_u16(out,&p,0x8664);dm_u16(out,&p,1);dm_u32(out,&p,0);dm_u32(out,&p,(d_u32)(60+n));dm_u32(out,&p,1);dm_u16(out,&p,0);dm_u16(out,&p,0);
 const char*sn=".text";for(int i=0;i<5;i++)out[p+i]=(d_u8)sn[i];p+=8;dm_u32(out,&p,0);dm_u32(out,&p,0);dm_u32(out,&p,(d_u32)n);dm_u32(out,&p,60);dm_u32(out,&p,0);dm_u32(out,&p,0);dm_u16(out,&p,0);dm_u16(out,&p,0);dm_u32(out,&p,0x60000020u);
 for(int i=0;i<n;i++)out[p++]=code[i];
 dm_u32(out,&p,0);dm_u32(out,&p,4);dm_u32(out,&p,0);dm_u16(out,&p,1);dm_u16(out,&p,0x20);out[p++]=2;out[p++]=0;dm_u32(out,&p,(d_u32)(4+sl));for(int i=0;i<sl-1;i++)out[p++]=(d_u8)sym[i];out[p++]=0;return p;}
#endif
