#ifndef DREAM_CBRIDGE_H
#define DREAM_CBRIDGE_H
#include "dream3_core.h"

#define DCB_MAX_IMPORTS 64
#define DCB_MAX_LINKS 64
#define DCB_MAX_CFLAGS 64
#define DCB_MAX_EXTERNS 128
#define DCB_MAX_EXPORTS 64
#define DCB_MAX_CCODE 65536
#define DCB_MAX_SOURCE 262144
#define DCB_MAX_ARGS 6

typedef struct { char text[160]; } DCBText;
typedef struct {
 char dll[96]; char ret[16]; char name[64]; int argc; char arg[DCB_MAX_ARGS][16];
} DCBExtern;
typedef struct { char name[64]; } DCBExport;
typedef struct {
 DCBText imports[DCB_MAX_IMPORTS]; int nimports;
 DCBText links[DCB_MAX_LINKS]; int nlinks;
 DCBText cflags[DCB_MAX_CFLAGS]; int ncflags;
 DCBExtern ext[DCB_MAX_EXTERNS]; int next;
 DCBExport exp[DCB_MAX_EXPORTS]; int nexp;
 char ccode[DCB_MAX_CCODE]; int ccode_n;
 char dream[DCB_MAX_SOURCE]; int dream_n;
 char error[192];
} DCB;

static int dcb_space(char c){return c==' '||c=='\t'||c=='\r'||c=='\n';}
static int dcb_ident0(char c){return d3_alpha(c);}
static int dcb_ident(char c){return d3_alnum(c);}
static int dcb_word(const char*s,int p,const char*w){int i=0;while(w[i]&&s[p+i]==w[i])i++;return !w[i]&&!dcb_ident(s[p+i]);}
static void dcb_zero(void*p,int n){d_u8*b=(d_u8*)p;for(int i=0;i<n;i++)b[i]=0;}
static int dcb_err(DCB*b,const char*s){if(!b->error[0])d3_copy(b->error,s,192);return 0;}
static int dcb_put(char*out,int*on,int cap,char c){if(*on>=cap-1)return 0;out[(*on)++]=c;out[*on]=0;return 1;}
static int dcb_cat(char*out,int*on,int cap,const char*s){for(int i=0;s&&s[i];i++)if(!dcb_put(out,on,cap,s[i]))return 0;return 1;}
static void dcb_skip(const char*s,int*p){while(s[*p]==' '||s[*p]=='\t'||s[*p]=='\r')(*p)++;}
static int dcb_id(const char*s,int*p,char*out,int cap){dcb_skip(s,p);if(!dcb_ident0(s[*p]))return 0;int n=0;while(dcb_ident(s[*p])){if(n<cap-1)out[n++]=s[*p];(*p)++;}out[n]=0;return 1;}
static int dcb_quoted(const char*s,int*p,char*out,int cap){dcb_skip(s,p);if(s[*p]!='\"'&&s[*p]!='\'')return 0;char q=s[(*p)++];int n=0;while(s[*p]&&s[*p]!=q){char c=s[(*p)++];if(c=='\\'&&s[*p]){if(n<cap-1)out[n++]=c;c=s[(*p)++];}if(n<cap-1)out[n++]=c;}if(s[*p]==q)(*p)++;out[n]=0;return 1;}
static int dcb_header(const char*s,int*p,char*out,int cap){dcb_skip(s,p);int n=0;if(s[*p]=='<'){do{if(n<cap-1)out[n++]=s[*p];}while(s[(*p)++]&&s[*p-1]!='>');out[n]=0;return n>1;}if(s[*p]=='\"'){if(n<cap-1)out[n++]=s[(*p)++];while(s[*p]&&s[*p]!='\"'){if(n<cap-1)out[n++]=s[*p];(*p)++;}if(s[*p]=='\"'){if(n<cap-1)out[n++]=s[*p];(*p)++;}out[n]=0;return n>2;}return 0;}
static int dcb_add_text(DCBText*a,int*n,int max,const char*s){if(*n>=max)return 0;d3_copy(a[*n].text,s,160);(*n)++;return 1;}
static int dcb_type_ok(const char*t){const char*ok[]={"void","i8","u8","i16","u16","i32","u32","i64","u64","ptr","cstr","size","bool","f32","f64",0};for(int i=0;ok[i];i++)if(d3_eq(t,ok[i]))return 1;return 0;}
static int dcb_ext_index(DCB*b,const char*n){for(int i=0;i<b->next;i++)if(d3_eq(b->ext[i].name,n))return i;return -1;}

/* Prepare Dream source: remove bridge directives and rewrite extern calls through native(api()). */
static int dcb_prepare(DCB*b,const char*src){
 dcb_zero(b,(int)sizeof(*b));char raw[DCB_MAX_SOURCE];int rn=0,p=0;
 while(src[p]){
  int ls=p,q=p;while(src[q]==' '||src[q]=='\t')q++;
  if(dcb_word(src,q,"cimport")){
   q+=7;char h[160];if(!dcb_header(src,&q,h,160))return dcb_err(b,"cimport expects <header.h> or \"header.h\"");if(!dcb_add_text(b->imports,&b->nimports,DCB_MAX_IMPORTS,h))return dcb_err(b,"too many cimport directives");while(src[q]&&src[q]!='\n')q++;p=src[q]?q+1:q;continue;
  }
  if(dcb_word(src,q,"link")){
   q+=4;char x[160];if(!dcb_quoted(src,&q,x,160))return dcb_err(b,"link expects a quoted library or linker flag");if(!dcb_add_text(b->links,&b->nlinks,DCB_MAX_LINKS,x))return dcb_err(b,"too many link directives");while(src[q]&&src[q]!='\n')q++;p=src[q]?q+1:q;continue;
  }
  if(dcb_word(src,q,"cflag")){
   q+=5;char x[160];if(!dcb_quoted(src,&q,x,160))return dcb_err(b,"cflag expects a quoted compiler flag");if(!dcb_add_text(b->cflags,&b->ncflags,DCB_MAX_CFLAGS,x))return dcb_err(b,"too many cflag directives");while(src[q]&&src[q]!='\n')q++;p=src[q]?q+1:q;continue;
  }
  if(dcb_word(src,q,"extern")){
   q+=6;dcb_skip(src,&q);if(!dcb_word(src,q,"c")){goto ordinary;}q++;if(b->next>=DCB_MAX_EXTERNS)return dcb_err(b,"too many extern c declarations");DCBExtern*e=&b->ext[b->next];
   dcb_skip(src,&q);if(src[q]=='\"'||src[q]=='\''){if(!dcb_quoted(src,&q,e->dll,96))return dcb_err(b,"bad extern c DLL string");}
   if(!dcb_id(src,&q,e->ret,16)||!dcb_type_ok(e->ret))return dcb_err(b,"extern c has unknown return type");if(!dcb_id(src,&q,e->name,64))return dcb_err(b,"extern c expects function name");dcb_skip(src,&q);if(src[q]!='(')return dcb_err(b,"extern c expects (types)");q++;dcb_skip(src,&q);e->argc=0;if(src[q]!=')')for(;;){if(e->argc>=DCB_MAX_ARGS)return dcb_err(b,"extern c supports up to six arguments");if(!dcb_id(src,&q,e->arg[e->argc],16)||!dcb_type_ok(e->arg[e->argc]))return dcb_err(b,"extern c has unknown argument type");e->argc++;dcb_skip(src,&q);if(src[q]==','){q++;continue;}break;}if(src[q]!=')')return dcb_err(b,"extern c expects )");q++;b->next++;while(src[q]&&src[q]!='\n')q++;p=src[q]?q+1:q;continue;
  }
  if(dcb_word(src,q,"export")){
   q+=6;dcb_skip(src,&q);if(!dcb_word(src,q,"c")){goto ordinary;}q++;if(b->nexp>=DCB_MAX_EXPORTS)return dcb_err(b,"too many export c declarations");if(!dcb_id(src,&q,b->exp[b->nexp].name,64))return dcb_err(b,"export c expects a Dream label");b->nexp++;while(src[q]&&src[q]!='\n')q++;p=src[q]?q+1:q;continue;
  }
  if(dcb_word(src,q,"c")){
   int z=q+1;dcb_skip(src,&z);if(src[z]=='{'){
    z++;int depth=1,quote=0,comment=0;char qc=0;while(src[z]&&depth){char c=src[z++];
     if(comment==1){if(b->ccode_n<DCB_MAX_CCODE-1)b->ccode[b->ccode_n++]=c;if(c=='\n')comment=0;continue;}
     if(comment==2){if(b->ccode_n<DCB_MAX_CCODE-1)b->ccode[b->ccode_n++]=c;if(c=='*'&&src[z]=='/'){if(b->ccode_n<DCB_MAX_CCODE-1)b->ccode[b->ccode_n++]=src[z++];comment=0;}continue;}
     if(quote){if(c=='\\'&&src[z]){if(b->ccode_n<DCB_MAX_CCODE-1)b->ccode[b->ccode_n++]=c;c=src[z++];if(b->ccode_n<DCB_MAX_CCODE-1)b->ccode[b->ccode_n++]=c;continue;}if(c==qc)quote=0;if(b->ccode_n<DCB_MAX_CCODE-1)b->ccode[b->ccode_n++]=c;continue;}
     if(c=='/'&&src[z]=='/'){if(b->ccode_n<DCB_MAX_CCODE-1)b->ccode[b->ccode_n++]=c;if(b->ccode_n<DCB_MAX_CCODE-1)b->ccode[b->ccode_n++]=src[z++];comment=1;continue;}
     if(c=='/'&&src[z]=='*'){if(b->ccode_n<DCB_MAX_CCODE-1)b->ccode[b->ccode_n++]=c;if(b->ccode_n<DCB_MAX_CCODE-1)b->ccode[b->ccode_n++]=src[z++];comment=2;continue;}
     if(c=='"'||c=='\''){quote=1;qc=c;if(b->ccode_n<DCB_MAX_CCODE-1)b->ccode[b->ccode_n++]=c;continue;}
     if(c=='{'){depth++;if(depth>1&&b->ccode_n<DCB_MAX_CCODE-1)b->ccode[b->ccode_n++]=c;continue;}
     if(c=='}'){depth--;if(depth&&b->ccode_n<DCB_MAX_CCODE-1)b->ccode[b->ccode_n++]=c;continue;}
     if(b->ccode_n>=DCB_MAX_CCODE-1)return dcb_err(b,"c block too large");b->ccode[b->ccode_n++]=c;
    }if(depth)return dcb_err(b,"unclosed c { } block");b->ccode[b->ccode_n++]='\n';b->ccode[b->ccode_n]=0;while(src[z]&&src[z]!='\n')z++;p=src[z]?z+1:z;continue;}
  }
ordinary:
  while(src[p]&&src[p]!='\n'){if(rn>=DCB_MAX_SOURCE-2)return dcb_err(b,"Dream source too large");raw[rn++]=src[p++];}if(src[p]=='\n'){raw[rn++]='\n';p++;}
  (void)ls;
 }
 raw[rn]=0;
 /* Rewrite calls to declared C functions while respecting strings/comments. */
 int i=0,on=0;while(raw[i]){
  if(raw[i]=='\"'||raw[i]=='\''){char q=raw[i];if(!dcb_put(b->dream,&on,DCB_MAX_SOURCE,raw[i++]))return dcb_err(b,"Dream source too large");while(raw[i]){char c=raw[i++];if(!dcb_put(b->dream,&on,DCB_MAX_SOURCE,c))return dcb_err(b,"Dream source too large");if(c=='\\'&&raw[i]){if(!dcb_put(b->dream,&on,DCB_MAX_SOURCE,raw[i++]))return dcb_err(b,"Dream source too large");continue;}if(c==q)break;}continue;}
  if(raw[i]=='/'&&raw[i+1]=='/'){while(raw[i]&&raw[i]!='\n')if(!dcb_put(b->dream,&on,DCB_MAX_SOURCE,raw[i++]))return dcb_err(b,"Dream source too large");continue;}
  if(raw[i]=='/'&&raw[i+1]=='*'){if(!dcb_put(b->dream,&on,DCB_MAX_SOURCE,raw[i++])||!dcb_put(b->dream,&on,DCB_MAX_SOURCE,raw[i++]))return dcb_err(b,"Dream source too large");while(raw[i]&&!(raw[i]=='*'&&raw[i+1]=='/'))if(!dcb_put(b->dream,&on,DCB_MAX_SOURCE,raw[i++]))return dcb_err(b,"Dream source too large");if(raw[i]){dcb_put(b->dream,&on,DCB_MAX_SOURCE,raw[i++]);dcb_put(b->dream,&on,DCB_MAX_SOURCE,raw[i++]);}continue;}
  if(dcb_ident0(raw[i])){char id[64];int k=0,j=i;while(dcb_ident(raw[j])){if(k<63)id[k++]=raw[j];j++;}id[k]=0;int e=dcb_ext_index(b,id),t=j;while(raw[t]==' '||raw[t]=='\t')t++;if(e>=0&&raw[t]=='('){DCBExtern*x=&b->ext[e];if(!dcb_cat(b->dream,&on,DCB_MAX_SOURCE,"native(api(\""))return dcb_err(b,"Dream source too large");if(!dcb_cat(b->dream,&on,DCB_MAX_SOURCE,x->dll))return dcb_err(b,"Dream source too large");if(!dcb_cat(b->dream,&on,DCB_MAX_SOURCE,"\",\""))return dcb_err(b,"Dream source too large");if(!dcb_cat(b->dream,&on,DCB_MAX_SOURCE,x->name))return dcb_err(b,"Dream source too large");if(!dcb_cat(b->dream,&on,DCB_MAX_SOURCE,"\")"))return dcb_err(b,"Dream source too large");int u=t+1;while(raw[u]==' '||raw[u]=='\t')u++;if(raw[u]!=')')if(!dcb_put(b->dream,&on,DCB_MAX_SOURCE,','))return dcb_err(b,"Dream source too large");i=t+1;continue;}while(i<j)if(!dcb_put(b->dream,&on,DCB_MAX_SOURCE,raw[i++]))return dcb_err(b,"Dream source too large");continue;}
  if(!dcb_put(b->dream,&on,DCB_MAX_SOURCE,raw[i++]))return dcb_err(b,"Dream source too large");
 }
 b->dream_n=on;return 1;
}

/* -------- C source generation -------- */
typedef struct { char*out; int n,cap; int bad; } DCBOut;
static void dco_s(DCBOut*o,const char*s){if(o->bad)return;for(int i=0;s&&s[i];i++){if(o->n>=o->cap-1){o->bad=1;return;}o->out[o->n++]=s[i];}o->out[o->n]=0;}
static void dco_i(DCBOut*o,d_i64 v){char b[48];d3_i64str(v,b);dco_s(o,b);}
static void dco_hex(DCBOut*o,d_u8 v){const char*h="0123456789ABCDEF";char b[6]={'0','x',h[v>>4],h[v&15],',',0};dco_s(o,b);}
static int dcb_label_pc(D3Program*p,const char*n){for(int i=0;i<p->nlabels;i++)if(d3_eq(p->labels[i].name,n))return p->labels[i].pc;return -1;}
static int dcb_var_id(D3Program*p,const char*n){for(int i=0;i<p->nvars;i++)if(d3_eq(p->vars[i].name,n))return i;return -1;}
static const char*dcb_ctype(const char*t){if(d3_eq(t,"void"))return "void";if(d3_eq(t,"i8"))return "signed char";if(d3_eq(t,"u8"))return "unsigned char";if(d3_eq(t,"i16"))return "short";if(d3_eq(t,"u16"))return "unsigned short";if(d3_eq(t,"i32")||d3_eq(t,"bool"))return "int";if(d3_eq(t,"u32"))return "unsigned int";if(d3_eq(t,"i64"))return "long long";if(d3_eq(t,"u64"))return "unsigned long long";if(d3_eq(t,"size"))return "size_t";if(d3_eq(t,"ptr"))return "void*";if(d3_eq(t,"cstr"))return "const char*";if(d3_eq(t,"f32"))return "float";if(d3_eq(t,"f64"))return "double";return "unsigned long long";}
static void dcb_argexpr(DCBOut*o,const char*t,int i){char n[3]={'a',(char)('0'+i),0};if(d3_eq(t,"ptr")){dco_s(o,"(void*)(uintptr_t)");dco_s(o,n);}else if(d3_eq(t,"cstr")){dco_s(o,"(const char*)(uintptr_t)");dco_s(o,n);}else if(d3_eq(t,"f64")){dco_s(o,"dcb_to_f64(");dco_s(o,n);dco_s(o,")");}else if(d3_eq(t,"f32")){dco_s(o,"dcb_to_f32(");dco_s(o,n);dco_s(o,")");}else{dco_s(o,"(");dco_s(o,dcb_ctype(t));dco_s(o,")");dco_s(o,n);}}
static int dcb_generate_c(DCB*b,D3Program*p,char*out,int cap){DCBOut o={out,0,cap,0};out[0]=0;
 dco_s(&o,"/* DREAM C 3.2 native C bridge output */\n#include <stdint.h>\n#include <stddef.h>\n#include <stdio.h>\n#include <stdlib.h>\n#include \"dream3_core.h\"\n#ifdef _WIN32\n#define WIN32_LEAN_AND_MEAN\n#include <windows.h>\n#else\n#include <dlfcn.h>\n#endif\n");
 for(int i=0;i<b->nimports;i++){dco_s(&o,"#include ");dco_s(&o,b->imports[i].text);dco_s(&o,"\n");}
 dco_s(&o,"\n");dco_s(&o,b->ccode);dco_s(&o,"\n");
 dco_s(&o,"static double dcb_to_f64(d_u64 x){union{d_u64 u;double d;}v;v.u=x;return v.d;}\nstatic float dcb_to_f32(d_u64 x){union{d_u32 u;float f;}v;v.u=(d_u32)x;return v.f;}\nstatic d_u64 dcb_from_f64(double x){union{d_u64 u;double d;}v;v.d=x;return v.u;}\nstatic d_u64 dcb_from_f32(float x){union{d_u32 u;float f;}v;v.f=x;return v.u;}\n");
 for(int e=0;e<b->next;e++){DCBExtern*x=&b->ext[e];dco_s(&o,"static d_u64 D3_MS dcb_wrap_");dco_s(&o,x->name);dco_s(&o,"(d_u64 a0,d_u64 a1,d_u64 a2,d_u64 a3,d_u64 a4,d_u64 a5){");if(d3_eq(x->ret,"void")){dco_s(&o,x->name);dco_s(&o,"(");}else if(d3_eq(x->ret,"f64")){dco_s(&o,"return dcb_from_f64(");dco_s(&o,x->name);dco_s(&o,"(");}else if(d3_eq(x->ret,"f32")){dco_s(&o,"return dcb_from_f32(");dco_s(&o,x->name);dco_s(&o,"(");}else if(d3_eq(x->ret,"ptr")||d3_eq(x->ret,"cstr")){dco_s(&o,"return (d_u64)(uintptr_t)");dco_s(&o,x->name);dco_s(&o,"(");}else{dco_s(&o,"return (d_u64)");dco_s(&o,x->name);dco_s(&o,"(");}for(int a=0;a<x->argc;a++){if(a)dco_s(&o,",");dcb_argexpr(&o,x->arg[a],a);}dco_s(&o,")");if(d3_eq(x->ret,"void")){dco_s(&o,";return 0;");}else if(d3_eq(x->ret,"f64")||d3_eq(x->ret,"f32"))dco_s(&o,");");else dco_s(&o,";");dco_s(&o,"}\n");}
 dco_s(&o,"static const unsigned char dcb_blob[]={");d_u8*bb=(d_u8*)p->code;int bytes=p->ncode*(int)sizeof(D3Ins);for(int i=0;i<bytes;i++){dco_hex(&o,bb[i]);if((i&31)==31)dco_s(&o,"\n");}dco_s(&o,"};\nstatic D3Program dcb_prog;static D3Host dcb_host;static int dcb_ready;\n");
 dco_s(&o,"static void dcb_out(void*c,const char*s){(void)c;fputs(s,stdout);}static void dcb_putc(void*c,char q){(void)c;fputc((unsigned char)q,stdout);}static void*dcb_alloc(void*c,d_u64 n){(void)c;return malloc((size_t)(n?n:1));}static void dcb_free(void*c,void*p){(void)c;free(p);}\n");
 dco_s(&o,"static d_u64 dcb_api(void*c,const char*dll,const char*name){(void)c;\n");for(int e=0;e<b->next;e++){dco_s(&o,"if(d3_eq(name,\"");dco_s(&o,b->ext[e].name);dco_s(&o,"\"))return (d_u64)(uintptr_t)&dcb_wrap_");dco_s(&o,b->ext[e].name);dco_s(&o,";");}dco_s(&o,"\n#ifdef _WIN32\nHMODULE m=LoadLibraryA(dll);return m?(d_u64)(uintptr_t)GetProcAddress(m,name):0;\n#else\nvoid*m=dlopen(dll,RTLD_LAZY);return m?(d_u64)(uintptr_t)dlsym(m,name):0;\n#endif\n}\n");
 dco_s(&o,"static void dcb_init(void){if(dcb_ready)return;d_u8*z=(d_u8*)&dcb_prog;for(int i=0;i<(int)sizeof(dcb_prog);i++)z[i]=0;for(int i=0;i<(int)sizeof(dcb_blob);i++)((d_u8*)dcb_prog.code)[i]=dcb_blob[i];dcb_prog.ncode=");dco_i(&o,p->ncode);dco_s(&o,";dcb_prog.nvars=");dco_i(&o,p->nvars);dco_s(&o,";dcb_host.out=dcb_out;dcb_host.putc_=dcb_putc;dcb_host.alloc=dcb_alloc;dcb_host.free_=dcb_free;dcb_host.api=dcb_api;dcb_host.ctx=0;dcb_ready=1;}\n");
 dco_s(&o,"#ifdef _WIN32\n#define DREAM_EXPORT __declspec(dllexport)\n#else\n#define DREAM_EXPORT __attribute__((visibility(\"default\")))\n#endif\n");
 int aidx[6],ridx=dcb_var_id(p,"result");for(int a=0;a<6;a++){char n[3]={'a',(char)('0'+a),0};aidx[a]=dcb_var_id(p,n);}for(int e=0;e<b->nexp;e++){int pc=dcb_label_pc(p,b->exp[e].name);if(pc<0)return 0;dco_s(&o,"DREAM_EXPORT d_u64 D3_MS ");dco_s(&o,b->exp[e].name);dco_s(&o,"(d_u64 a0,d_u64 a1,d_u64 a2,d_u64 a3,d_u64 a4,d_u64 a5){dcb_init();D3VM v;d3_vmreset(&v);");for(int a=0;a<6;a++)if(aidx[a]>=0){dco_s(&o,"v.vars[");dco_i(&o,aidx[a]);dco_s(&o,"]=a");char q[2]={(char)('0'+a),0};dco_s(&o,q);dco_s(&o,";");}dco_s(&o,"d3_exec(&dcb_prog,&dcb_host,&v,");dco_i(&o,pc);dco_s(&o,",100000000);return ");if(ridx>=0){dco_s(&o,"(d_u64)v.vars[");dco_i(&o,ridx);dco_s(&o,"];");}else dco_s(&o,"0;");dco_s(&o,"}\n");}
 dco_s(&o,"int main(void){dcb_init();D3VM v;if(!d3_run(&dcb_prog,&dcb_host,&v,100000000)){fprintf(stderr,\"DREAM VM FAULT: %s\\n\",v.error_text);return 2;}return 0;}\n");
 return o.bad?0:o.n;
}

static int dcb_build_command(DCB*b,const char*cfile,const char*exe,char*out,int cap,const char*cc){int n=0;out[0]=0;if(!dcb_cat(out,&n,cap,cc?cc:"gcc"))return 0;if(!dcb_cat(out,&n,cap," -O2 -std=c11 -I. "))return 0;for(int i=0;i<b->ncflags;i++){if(!dcb_cat(out,&n,cap,b->cflags[i].text)||!dcb_put(out,&n,cap,' '))return 0;}if(!dcb_cat(out,&n,cap,"\"" )||!dcb_cat(out,&n,cap,cfile)||!dcb_cat(out,&n,cap,"\" -o \"")||!dcb_cat(out,&n,cap,exe)||!dcb_cat(out,&n,cap,"\" "))return 0;for(int i=0;i<b->nlinks;i++){const char*x=b->links[i].text;int needs=0;for(int j=0;x[j];j++)if(x[j]==' ')needs=1;if(needs)dcb_put(out,&n,cap,'\"');if(!dcb_cat(out,&n,cap,x))return 0;if(needs)dcb_put(out,&n,cap,'\"');if(!dcb_put(out,&n,cap,' '))return 0;}
 return n;
}

#endif
