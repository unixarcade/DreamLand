#ifndef DREAM3_CORE_H
#define DREAM3_CORE_H

/* DREAM C 3.2 core: tiny compiler + stack VM. No CRT required. */
typedef unsigned char d_u8;
typedef unsigned short d_u16;
typedef unsigned int d_u32;
typedef signed int d_i32;
typedef unsigned long long d_u64;
typedef long long d_i64;

#define D3_MAX_CODE 8192
#define D3_MAX_VARS 256
#define D3_MAX_LABELS 512
#define D3_MAX_MACROS 64
#define D3_MAX_STACK 2048
#define D3_MAX_CALL 256
#define D3_MAX_USTACK 1024
#define D3_TEXT 112
#define D3_RAW 96
#define D3_MS __attribute__((ms_abi))

enum {
 D3_NOP=0,
 D3_PUSHI, D3_PUSHS, D3_LOAD, D3_STORE, D3_DUP, D3_DROP,
 D3_ADD, D3_SUB, D3_MUL, D3_DIV, D3_MOD, D3_SHL, D3_SHR,
 D3_BAND, D3_BOR, D3_BXOR, D3_LAND, D3_LOR,
 D3_EQ, D3_NE, D3_LT, D3_LE, D3_GT, D3_GE,
 D3_NEG, D3_LNOT, D3_BNOT, D3_WEAVE, D3_FLOW, D3_EMIT,
 D3_PRINTI, D3_PRINTS, D3_PUTC,
 D3_JMP, D3_JZ, D3_JNZ, D3_CALL, D3_RET, D3_HALT,
 D3_PEEK8, D3_PEEK16, D3_PEEK32, D3_PEEK64,
 D3_POKE8, D3_POKE16, D3_POKE32, D3_POKE64,
 D3_ALLOC, D3_FREE, D3_API, D3_NATIVE,
 D3_UPUSH, D3_UPOP, D3_ASM
};

typedef struct {
 d_u8 op;
 d_u8 a;
 d_u16 n;
 d_i32 target;
 d_i32 aux;
 d_i64 imm;
 char text[D3_TEXT];
 d_u8 raw[D3_RAW];
} D3Ins;

typedef struct {
 char magic[4];
 d_u32 version;
 d_u32 ncode;
 d_u32 nvars;
 d_u32 reserved;
} D3Head;

typedef struct { char name[40]; d_i32 pc; } D3Label;
typedef struct { char name[40]; } D3Var;
typedef struct { char name[40]; d_u8 isstr; d_i64 num; char text[D3_TEXT]; } D3Macro;

typedef struct {
 D3Ins code[D3_MAX_CODE];
 d_i32 ncode;
 D3Label labels[D3_MAX_LABELS];
 d_i32 nlabels;
 D3Var vars[D3_MAX_VARS];
 d_i32 nvars;
 d_i32 error_line;
 char error[160];
} D3Program;

/* ---------- tiny utilities ---------- */
static int d3_len(const char*s){int n=0;while(s&&s[n])n++;return n;}
static int d3_eq(const char*a,const char*b){int i=0;for(;;i++){if(a[i]!=b[i])return 0;if(!a[i])return 1;}}
static void d3_copy(char*d,const char*s,int cap){int i=0;if(cap<1)return;while(s&&s[i]&&i<cap-1){d[i]=s[i];i++;}d[i]=0;}
static int d3_alpha(char c){return (c>='a'&&c<='z')||(c>='A'&&c<='Z')||c=='_';}
static int d3_digit(char c){return c>='0'&&c<='9';}
static int d3_alnum(char c){return d3_alpha(c)||d3_digit(c);}
static int d3_hex(char c){if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return 10+c-'a';if(c>='A'&&c<='F')return 10+c-'A';return -1;}
static d_i64 d3_parse_num(const char*s){
 d_i64 sign=1,v=0;int i=0;if(s[i]=='-'){sign=-1;i++;}
 if(s[i]=='0'&&(s[i+1]=='x'||s[i+1]=='X')){i+=2;for(;;i++){int h=d3_hex(s[i]);if(h<0)break;v=(v<<4)|h;}return v*sign;}
 while(d3_digit(s[i])){v=v*10+(s[i]-'0');i++;}return v*sign;
}
static void d3_i64str(d_i64 v,char*b){char t[32];int n=0,i=0;d_u64 u;if(v<0){b[i++]='-';u=(d_u64)(-(v+1))+1;}else u=(d_u64)v;do{t[n++]=(char)('0'+u%10);u/=10;}while(u);while(n)b[i++]=t[--n];b[i]=0;}

/* ---------- lexer ---------- */
enum {
 T_EOF=0,T_ID=256,T_NUM,T_STR,T_EQEQ,T_NE,T_LE,T_GE,T_SHL,T_SHR,T_LAND,T_LOR,
 T_WEAVE,T_MATCH,T_RESONATE,T_FLOW,T_EMIT
};
typedef struct {
 const char* src; int p,line,tok; d_i64 num; char text[160];
} D3Lex;

static void d3_lex_skip(D3Lex*l){
 for(;;){
  char c=l->src[l->p];
  if(c==' '||c=='\t'||c=='\r'){l->p++;continue;}
  if(c=='\n'){l->p++;l->line++;continue;}
  if(c=='#'){while(l->src[l->p]&&l->src[l->p]!='\n')l->p++;continue;}
  if(c=='/'&&l->src[l->p+1]=='/'){l->p+=2;while(l->src[l->p]&&l->src[l->p]!='\n')l->p++;continue;}
  if(c=='/'&&l->src[l->p+1]=='*'){l->p+=2;while(l->src[l->p]&&!(l->src[l->p]=='*'&&l->src[l->p+1]=='/')){if(l->src[l->p++]=='\n')l->line++;}if(l->src[l->p])l->p+=2;continue;}
  break;
 }
}
static void d3_next(D3Lex*l){
 d3_lex_skip(l);l->text[0]=0;l->num=0;char c=l->src[l->p];
 if(!c){l->tok=T_EOF;return;}
 if(d3_alpha(c)){
  int n=0;while(d3_alnum(l->src[l->p])){if(n<159)l->text[n++]=l->src[l->p];l->p++;}l->text[n]=0;l->tok=T_ID;return;
 }
 if(d3_digit(c)){
  int n=0;if(c=='0'&&(l->src[l->p+1]=='x'||l->src[l->p+1]=='X')){if(n<159)l->text[n++]=l->src[l->p++];if(n<159)l->text[n++]=l->src[l->p++];while(d3_hex(l->src[l->p])>=0){if(n<159)l->text[n++]=l->src[l->p];l->p++;}}
  else while(d3_hex(l->src[l->p])>=0){if(n<159)l->text[n++]=l->src[l->p];l->p++;}
  l->text[n]=0;l->num=d3_parse_num(l->text);l->tok=T_NUM;return;
 }
 if(c=='"'){
  l->p++;int n=0;while(l->src[l->p]&&l->src[l->p]!='"'){
   char q=l->src[l->p++];if(q=='\\'){
    char e=l->src[l->p++];if(e=='n')q='\n';else if(e=='r')q='\r';else if(e=='t')q='\t';else if(e=='e')q=27;else if(e=='0')q=0;else q=e;
   }
   if(n<159)l->text[n++]=q;
  }if(l->src[l->p]=='"')l->p++;l->text[n]=0;l->tok=T_STR;return;
 }
 #define D3_TWO(a,b,t) if(c==(a)&&l->src[l->p+1]==(b)){l->p+=2;l->tok=(t);return;}
 D3_TWO('=','=',T_EQEQ) D3_TWO('!','=',T_NE) D3_TWO('<','=',T_LE) D3_TWO('>','=',T_GE)
 D3_TWO('<','<',T_SHL) D3_TWO('>','>',T_SHR) D3_TWO('&','&',T_LAND) D3_TWO('|','|',T_LOR)
 D3_TWO('%','%',T_WEAVE) D3_TWO('?','=',T_MATCH)
 if(c=='<'&&l->src[l->p+1]=='-'&&l->src[l->p+2]=='>'){l->p+=3;l->tok=T_RESONATE;return;}
 if(c=='-'&&l->src[l->p+1]=='>'&&l->src[l->p+2]=='>'){l->p+=3;l->tok=T_FLOW;return;}
 if(c=='@'&&l->src[l->p+1]=='>'){l->p+=2;l->tok=T_EMIT;return;}
 #undef D3_TWO
 l->p++;l->tok=(unsigned char)c;
}

/* ---------- compiler ---------- */
typedef struct {D3Program* p;D3Lex l;D3Macro macros[D3_MAX_MACROS];int nmacros;} D3C;
static int d3_fail(D3C*c,const char*m){if(!c->p->error[0]){c->p->error_line=c->l.line;d3_copy(c->p->error,m,160);}return 0;}
static D3Ins* d3_emit(D3C*c,int op){if(c->p->ncode>=D3_MAX_CODE){d3_fail(c,"program too large");return 0;}D3Ins*i=&c->p->code[c->p->ncode++];d_u8*z=(d_u8*)i;for(int k=0;k<(int)sizeof(*i);k++)z[k]=0;i->op=(d_u8)op;return i;}
static int d3_var(D3C*c,const char*n){for(int i=0;i<c->p->nvars;i++)if(d3_eq(c->p->vars[i].name,n))return i;if(c->p->nvars>=D3_MAX_VARS){d3_fail(c,"too many variables");return -1;}int id=c->p->nvars++;d3_copy(c->p->vars[id].name,n,40);return id;}
static int d3_label(D3C*c,const char*n){for(int i=0;i<c->p->nlabels;i++)if(d3_eq(c->p->labels[i].name,n))return i;if(c->p->nlabels>=D3_MAX_LABELS){d3_fail(c,"too many labels");return -1;}int id=c->p->nlabels++;d3_copy(c->p->labels[id].name,n,40);c->p->labels[id].pc=-1;return id;}
static int d3_accept(D3C*c,int t){if(c->l.tok==t){d3_next(&c->l);return 1;}return 0;}
static int d3_expect(D3C*c,int t,const char*m){if(c->l.tok!=t)return d3_fail(c,m);d3_next(&c->l);return 1;}
static int d3_isid(D3C*c,const char*n){return c->l.tok==T_ID&&d3_eq(c->l.text,n);}
static int d3_macro_find(D3C*c,const char*n){for(int i=0;i<c->nmacros;i++)if(d3_eq(c->macros[i].name,n))return i;return -1;}
static int d3_macro_new(D3C*c,const char*n){int i=d3_macro_find(c,n);if(i>=0)return i;if(c->nmacros>=D3_MAX_MACROS){d3_fail(c,"too many macros");return -1;}i=c->nmacros++;d3_copy(c->macros[i].name,n,40);c->macros[i].isstr=0;c->macros[i].num=0;c->macros[i].text[0]=0;return i;}

static int d3_expr(D3C*c);

static int d3_builtin_call(D3C*c,const char*name){
 /* current token is '(' */
 if(!d3_expect(c,'(',"expected ("))return 0;
 if(d3_eq(name,"peek8")||d3_eq(name,"peek16")||d3_eq(name,"peek32")||d3_eq(name,"peek64")||d3_eq(name,"alloc")||d3_eq(name,"free")||d3_eq(name,"push")){
  if(!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;
  int op=d3_eq(name,"peek8")?D3_PEEK8:d3_eq(name,"peek16")?D3_PEEK16:d3_eq(name,"peek32")?D3_PEEK32:d3_eq(name,"peek64")?D3_PEEK64:d3_eq(name,"alloc")?D3_ALLOC:d3_eq(name,"free")?D3_FREE:D3_UPUSH;
  d3_emit(c,op);return c->p->error[0]?0:1;
 }
 if(d3_eq(name,"poke8")||d3_eq(name,"poke16")||d3_eq(name,"poke32")||d3_eq(name,"poke64")){
  if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;
  d3_emit(c,d3_eq(name,"poke8")?D3_POKE8:d3_eq(name,"poke16")?D3_POKE16:d3_eq(name,"poke32")?D3_POKE32:D3_POKE64);return 1;
 }
 if(d3_eq(name,"pop")){
  if(!d3_expect(c,')',"expected )"))return 0;d3_emit(c,D3_UPOP);return 1;
 }
 if(d3_eq(name,"api")){
  if(!d3_expr(c)||!d3_expect(c,',',"expected ,")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;d3_emit(c,D3_API);return 1;
 }
 if(d3_eq(name,"native")){
  int argc=0;if(c->l.tok!=')'){
   if(!d3_expr(c))return 0;
   while(d3_accept(c,',')){if(argc>=6)return d3_fail(c,"native supports 6 args");if(!d3_expr(c))return 0;argc++;}
   /* first expression is function; remaining count = commas */
  }
  if(!d3_expect(c,')',"expected )"))return 0;
  D3Ins*i=d3_emit(c,D3_NATIVE);if(i)i->a=(d_u8)argc;return i!=0;
 }
 return d3_fail(c,"unknown builtin call");
}

static int d3_primary(D3C*c){
 if(c->l.tok==T_NUM){D3Ins*i=d3_emit(c,D3_PUSHI);if(i)i->imm=c->l.num;d3_next(&c->l);return i!=0;}
 if(c->l.tok==T_STR){D3Ins*i=d3_emit(c,D3_PUSHS);if(i)d3_copy(i->text,c->l.text,D3_TEXT);d3_next(&c->l);return i!=0;}
 if(d3_accept(c,'(')){if(!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;return 1;}
 if(c->l.tok==T_ID){
  char name[80];d3_copy(name,c->l.text,80);d3_next(&c->l);
  int mid=d3_macro_find(c,name);if(mid>=0){D3Ins*i=d3_emit(c,c->macros[mid].isstr?D3_PUSHS:D3_PUSHI);if(!i)return 0;if(c->macros[mid].isstr)d3_copy(i->text,c->macros[mid].text,D3_TEXT);else i->imm=c->macros[mid].num;return 1;}
  if(d3_eq(name,"asm")){
   if(!d3_expect(c,'{',"expected { after asm"))return 0;D3Ins*i=d3_emit(c,D3_ASM);if(!i)return 0;int n=0;
   while(c->l.tok!=T_EOF&&c->l.tok!='}'){
    char tmp[160];d3_copy(tmp,c->l.text,160);
    if(c->l.tok==T_NUM&&tmp[0]==0){d3_i64str(c->l.num,tmp);}
    if(c->l.tok!=T_NUM&&c->l.tok!=T_ID)return d3_fail(c,"asm expects hex bytes");
    int L=d3_len(tmp);if(L!=2||d3_hex(tmp[0])<0||d3_hex(tmp[1])<0)return d3_fail(c,"asm bytes must be two hex digits");
    if(n>=D3_RAW)return d3_fail(c,"asm block too large");i->raw[n++]=(d_u8)((d3_hex(tmp[0])<<4)|d3_hex(tmp[1]));d3_next(&c->l);
   }
   if(!d3_expect(c,'}',"expected }"))return 0;i->n=(d_u16)n;return 1;
  }
  if(c->l.tok=='(')return d3_builtin_call(c,name);
  int id=d3_var(c,name);if(id<0)return 0;D3Ins*i=d3_emit(c,D3_LOAD);if(i)i->a=(d_u8)id;return i!=0;
 }
 return d3_fail(c,"expected expression");
}
static int d3_unary(D3C*c){if(d3_accept(c,'-')){if(!d3_unary(c))return 0;d3_emit(c,D3_NEG);return 1;}if(d3_accept(c,'!')){if(!d3_unary(c))return 0;d3_emit(c,D3_LNOT);return 1;}if(d3_accept(c,'~')){if(!d3_unary(c))return 0;d3_emit(c,D3_BNOT);return 1;}return d3_primary(c);}
static int d3_mul(D3C*c){if(!d3_unary(c))return 0;for(;;){int t=c->l.tok,op=0;if(t=='*')op=D3_MUL;else if(t=='/')op=D3_DIV;else if(t=='%')op=D3_MOD;else if(t==T_WEAVE)op=D3_WEAVE;else break;d3_next(&c->l);if(!d3_unary(c))return 0;d3_emit(c,op);}return 1;}
static int d3_add(D3C*c){if(!d3_mul(c))return 0;while(c->l.tok=='+'||c->l.tok=='-'){int op=c->l.tok=='+'?D3_ADD:D3_SUB;d3_next(&c->l);if(!d3_mul(c))return 0;d3_emit(c,op);}return 1;}
static int d3_shift(D3C*c){if(!d3_add(c))return 0;while(c->l.tok==T_SHL||c->l.tok==T_SHR){int op=c->l.tok==T_SHL?D3_SHL:D3_SHR;d3_next(&c->l);if(!d3_add(c))return 0;d3_emit(c,op);}return 1;}
static int d3_rel(D3C*c){if(!d3_shift(c))return 0;for(;;){int t=c->l.tok,op=0;if(t=='<')op=D3_LT;else if(t=='>')op=D3_GT;else if(t==T_LE)op=D3_LE;else if(t==T_GE)op=D3_GE;else break;d3_next(&c->l);if(!d3_shift(c))return 0;d3_emit(c,op);}return 1;}
static int d3_equality(D3C*c){if(!d3_rel(c))return 0;for(;;){int t=c->l.tok,op=0;if(t==T_EQEQ||t==T_MATCH)op=D3_EQ;else if(t==T_NE)op=D3_NE;else break;d3_next(&c->l);if(!d3_rel(c))return 0;d3_emit(c,op);}return 1;}
static int d3_band(D3C*c){if(!d3_equality(c))return 0;while(c->l.tok=='&'){d3_next(&c->l);if(!d3_equality(c))return 0;d3_emit(c,D3_BAND);}return 1;}
static int d3_bxor(D3C*c){if(!d3_band(c))return 0;while(c->l.tok=='^'||c->l.tok==T_RESONATE){d3_next(&c->l);if(!d3_band(c))return 0;d3_emit(c,D3_BXOR);}return 1;}
static int d3_bor(D3C*c){if(!d3_bxor(c))return 0;while(c->l.tok=='|'){d3_next(&c->l);if(!d3_bxor(c))return 0;d3_emit(c,D3_BOR);}return 1;}
static int d3_land(D3C*c){if(!d3_bor(c))return 0;while(c->l.tok==T_LAND){d3_next(&c->l);if(!d3_bor(c))return 0;d3_emit(c,D3_LAND);}return 1;}
static int d3_expr(D3C*c){if(!d3_land(c))return 0;while(c->l.tok==T_LOR){d3_next(&c->l);if(!d3_land(c))return 0;d3_emit(c,D3_LOR);}while(c->l.tok==T_FLOW||c->l.tok==T_EMIT){int op=c->l.tok==T_FLOW?D3_FLOW:D3_EMIT;d3_next(&c->l);if(!d3_land(c))return 0;d3_emit(c,op);}return 1;}

static int d3_semicolon(D3C*c){if(c->l.tok==';'){d3_next(&c->l);return 1;}return 1; /* newline is whitespace; semicolon optional */}

static int d3_statement(D3C*c){
 if(c->l.tok==T_EOF)return 1;
 D3Lex save=c->l;
 if(c->l.tok==T_ID){
  char name[80];d3_copy(name,c->l.text,80);d3_next(&c->l);
  if(c->l.tok==':'){int id=d3_label(c,name);if(id<0)return 0;c->p->labels[id].pc=c->p->ncode;d3_next(&c->l);return 1;}
  c->l=save;
 }
 if(d3_isid(c,"macro")){
  d3_next(&c->l);if(c->l.tok!=T_ID)return d3_fail(c,"expected macro name");char n[80];d3_copy(n,c->l.text,80);d3_next(&c->l);if(!d3_expect(c,'=',"expected ="))return 0;int id=d3_macro_new(c,n);if(id<0)return 0;
  if(c->l.tok==T_STR){c->macros[id].isstr=1;d3_copy(c->macros[id].text,c->l.text,D3_TEXT);d3_next(&c->l);}
  else if(c->l.tok==T_NUM){c->macros[id].isstr=0;c->macros[id].num=c->l.num;d3_next(&c->l);}
  else return d3_fail(c,"macro requires number or string");d3_semicolon(c);return 1;
 }
 if(d3_isid(c,"var")||d3_isid(c,"int")||d3_isid(c,"ptr")){
  d3_next(&c->l);if(c->l.tok!=T_ID)return d3_fail(c,"expected variable name");char n[80];d3_copy(n,c->l.text,80);d3_next(&c->l);int id=d3_var(c,n);if(id<0)return 0;
  if(d3_accept(c,'=')){if(!d3_expr(c))return 0;}else{D3Ins*z=d3_emit(c,D3_PUSHI);if(z)z->imm=0;}
  D3Ins*s=d3_emit(c,D3_STORE);if(s)s->a=(d_u8)id;d3_semicolon(c);return s!=0;
 }
 if(d3_isid(c,"print")||d3_isid(c,"println")){
  int newline=d3_eq(c->l.text,"println");d3_next(&c->l);if(!d3_expect(c,'(',"expected ("))return 0;
  if(c->l.tok!=')')for(;;){int isstr=c->l.tok==T_STR||(c->l.tok==T_ID&&d3_macro_find(c,c->l.text)>=0&&c->macros[d3_macro_find(c,c->l.text)].isstr);if(!d3_expr(c))return 0;d3_emit(c,isstr?D3_PRINTS:D3_PRINTI);if(!d3_accept(c,','))break;}
  if(!d3_expect(c,')',"expected )"))return 0;if(newline){D3Ins*i=d3_emit(c,D3_PUSHS);if(i)d3_copy(i->text,"\r\n",D3_TEXT);d3_emit(c,D3_PRINTS);}d3_semicolon(c);return 1;
 }
 if(d3_isid(c,"putc")){
  d3_next(&c->l);if(!d3_expect(c,'(',"expected (")||!d3_expr(c)||!d3_expect(c,')',"expected )"))return 0;d3_emit(c,D3_PUTC);d3_semicolon(c);return 1;
 }
 if(d3_isid(c,"goto")){
  d3_next(&c->l);if(c->l.tok!=T_ID)return d3_fail(c,"expected label");D3Ins*i=d3_emit(c,D3_JMP);if(i)d3_copy(i->text,c->l.text,D3_TEXT);d3_next(&c->l);d3_semicolon(c);return i!=0;
 }
 if(d3_isid(c,"call")||d3_isid(c,"gosub")){
  d3_next(&c->l);if(c->l.tok!=T_ID)return d3_fail(c,"expected label");D3Ins*i=d3_emit(c,D3_CALL);if(i)d3_copy(i->text,c->l.text,D3_TEXT);d3_next(&c->l);d3_semicolon(c);return i!=0;
 }
 if(d3_isid(c,"return")||d3_isid(c,"ret")){d3_next(&c->l);d3_emit(c,D3_RET);d3_semicolon(c);return 1;}
 if(d3_isid(c,"halt")||d3_isid(c,"end")){d3_next(&c->l);d3_emit(c,D3_HALT);d3_semicolon(c);return 1;}
 if(d3_isid(c,"if")){
  d3_next(&c->l);if(!d3_expr(c))return 0;if(!d3_isid(c,"goto"))return d3_fail(c,"if requires goto");d3_next(&c->l);if(c->l.tok!=T_ID)return d3_fail(c,"expected label");D3Ins*i=d3_emit(c,D3_JNZ);if(i)d3_copy(i->text,c->l.text,D3_TEXT);d3_next(&c->l);d3_semicolon(c);return i!=0;
 }
 /* assignment */
 if(c->l.tok==T_ID){
  D3Lex ss=c->l;char n[80];d3_copy(n,c->l.text,80);d3_next(&c->l);
  if(c->l.tok=='='){d3_next(&c->l);if(!d3_expr(c))return 0;int id=d3_var(c,n);D3Ins*i=d3_emit(c,D3_STORE);if(i)i->a=(d_u8)id;d3_semicolon(c);return i!=0;}
  c->l=ss;
 }
 /* expression statement, including asm{}, poke(), free(), native(), etc. */
 if(!d3_expr(c))return 0;d3_emit(c,D3_DROP);d3_semicolon(c);return 1;
}

static int d3_compile(D3Program*p,const char*src){
 d_u8*z=(d_u8*)p;for(int i=0;i<(int)sizeof(*p);i++)z[i]=0;D3C c;c.p=p;c.nmacros=0;c.l.src=src;c.l.p=0;c.l.line=1;d3_next(&c.l);
 while(c.l.tok!=T_EOF&&!p->error[0])if(!d3_statement(&c))break;
 if(p->error[0])return 0;
 /* patch labels */
 for(int i=0;i<p->ncode;i++)if(p->code[i].op==D3_JMP||p->code[i].op==D3_JZ||p->code[i].op==D3_JNZ||p->code[i].op==D3_CALL){int id=-1;for(int j=0;j<p->nlabels;j++)if(d3_eq(p->labels[j].name,p->code[i].text)){id=j;break;}if(id<0||p->labels[id].pc<0){p->error_line=0;d3_copy(p->error,"unknown label",160);return 0;}p->code[i].target=p->labels[id].pc;}
 return 1;
}

/* ---------- VM ---------- */
typedef struct {
 void (*out)(void*ctx,const char*s);
 void (*putc_)(void*ctx,char c);
 void* (*alloc)(void*ctx,d_u64 n);
 void (*free_)(void*ctx,void*p);
 d_u64 (*api)(void*ctx,const char*dll,const char*name);
 void* ctx;
} D3Host;

typedef struct {
 d_i64 vars[D3_MAX_VARS]; d_i64 stack[D3_MAX_STACK]; int sp;
 int calls[D3_MAX_CALL],csp; d_i64 ustack[D3_MAX_USTACK];int usp;
 int error; char error_text[128];
} D3VM;
static void d3_vmfail(D3VM*v,const char*s){v->error=1;d3_copy(v->error_text,s,128);}
static void d3_push(D3VM*v,d_i64 x){if(v->sp>=D3_MAX_STACK)d3_vmfail(v,"stack overflow");else v->stack[v->sp++]=x;}
static d_i64 d3_pop(D3VM*v){if(v->sp<=0){d3_vmfail(v,"stack underflow");return 0;}return v->stack[--v->sp];}
static d_u64 d3_weave(d_u64 a,d_u64 b){d_u64 r=0;for(int i=0;i<32;i++){r|=((a>>i)&1ull)<<(2*i);r|=((b>>i)&1ull)<<(2*i+1);}return r;}
static d_u64 d3_native_call(d_u64 f,int n,d_u64*a){
 typedef d_u64 (D3_MS *F0)(void);typedef d_u64 (D3_MS *F1)(d_u64);typedef d_u64 (D3_MS *F2)(d_u64,d_u64);typedef d_u64 (D3_MS *F3)(d_u64,d_u64,d_u64);typedef d_u64 (D3_MS *F4)(d_u64,d_u64,d_u64,d_u64);typedef d_u64 (D3_MS *F5)(d_u64,d_u64,d_u64,d_u64,d_u64);typedef d_u64 (D3_MS *F6)(d_u64,d_u64,d_u64,d_u64,d_u64,d_u64);
 if(!f)return 0;switch(n){case 0:return ((F0)f)();case 1:return ((F1)f)(a[0]);case 2:return ((F2)f)(a[0],a[1]);case 3:return ((F3)f)(a[0],a[1],a[2]);case 4:return ((F4)f)(a[0],a[1],a[2],a[3]);case 5:return ((F5)f)(a[0],a[1],a[2],a[3],a[4]);default:return ((F6)f)(a[0],a[1],a[2],a[3],a[4],a[5]);}
}
static void d3_vmreset(D3VM*v){d_u8*z=(d_u8*)v;for(int i=0;i<(int)sizeof(*v);i++)z[i]=0;}
static int d3_exec(D3Program*p,D3Host*h,D3VM*v,int startpc,int maxsteps){
 int pc=startpc,steps=0;char nb[48];
 while(pc>=0&&pc<p->ncode&&!v->error&&steps++<maxsteps){D3Ins*i=&p->code[pc++];d_i64 a,b;switch(i->op){
  case D3_NOP:break;case D3_PUSHI:d3_push(v,i->imm);break;case D3_PUSHS:d3_push(v,(d_i64)(d_u64)(void*)i->text);break;
  case D3_LOAD:d3_push(v,v->vars[i->a]);break;case D3_STORE:v->vars[i->a]=d3_pop(v);break;case D3_DUP:a=d3_pop(v);d3_push(v,a);d3_push(v,a);break;case D3_DROP:(void)d3_pop(v);break;
  case D3_ADD:b=d3_pop(v);a=d3_pop(v);d3_push(v,a+b);break;case D3_SUB:b=d3_pop(v);a=d3_pop(v);d3_push(v,a-b);break;case D3_MUL:b=d3_pop(v);a=d3_pop(v);d3_push(v,a*b);break;
  case D3_DIV:b=d3_pop(v);a=d3_pop(v);d3_push(v,b?a/b:0);break;case D3_MOD:b=d3_pop(v);a=d3_pop(v);d3_push(v,b?a%b:0);break;case D3_SHL:b=d3_pop(v);a=d3_pop(v);d3_push(v,(d_i64)((d_u64)a<<(b&63)));break;case D3_SHR:b=d3_pop(v);a=d3_pop(v);d3_push(v,(d_i64)((d_u64)a>>(b&63)));break;
  case D3_BAND:b=d3_pop(v);a=d3_pop(v);d3_push(v,a&b);break;case D3_BOR:b=d3_pop(v);a=d3_pop(v);d3_push(v,a|b);break;case D3_BXOR:b=d3_pop(v);a=d3_pop(v);d3_push(v,a^b);break;case D3_LAND:b=d3_pop(v);a=d3_pop(v);d3_push(v,(a&&b)?1:0);break;case D3_LOR:b=d3_pop(v);a=d3_pop(v);d3_push(v,(a||b)?1:0);break;
  case D3_EQ:b=d3_pop(v);a=d3_pop(v);d3_push(v,a==b);break;case D3_NE:b=d3_pop(v);a=d3_pop(v);d3_push(v,a!=b);break;case D3_LT:b=d3_pop(v);a=d3_pop(v);d3_push(v,a<b);break;case D3_LE:b=d3_pop(v);a=d3_pop(v);d3_push(v,a<=b);break;case D3_GT:b=d3_pop(v);a=d3_pop(v);d3_push(v,a>b);break;case D3_GE:b=d3_pop(v);a=d3_pop(v);d3_push(v,a>=b);break;
  case D3_NEG:d3_push(v,-d3_pop(v));break;case D3_LNOT:d3_push(v,!d3_pop(v));break;case D3_BNOT:d3_push(v,~d3_pop(v));break;case D3_WEAVE:b=d3_pop(v);a=d3_pop(v);d3_push(v,(d_i64)d3_weave((d_u64)a,(d_u64)b));break;case D3_FLOW:{d_u64 fn=(d_u64)d3_pop(v),arg=(d_u64)d3_pop(v),aa[1]={arg};d3_push(v,(d_i64)d3_native_call(fn,1,aa));}break;case D3_EMIT:{d_u64 addr=(d_u64)d3_pop(v),val=(d_u64)d3_pop(v);*(volatile d_u64*)addr=val;d3_push(v,(d_i64)val);}break;
  case D3_PRINTI:a=d3_pop(v);d3_i64str(a,nb);if(h&&h->out)h->out(h->ctx,nb);break;case D3_PRINTS:a=d3_pop(v);if(h&&h->out)h->out(h->ctx,(const char*)(d_u64)a);break;case D3_PUTC:a=d3_pop(v);if(h&&h->putc_)h->putc_(h->ctx,(char)a);break;
  case D3_JMP:pc=i->target;break;case D3_JZ:if(!d3_pop(v))pc=i->target;break;case D3_JNZ:if(d3_pop(v))pc=i->target;break;case D3_CALL:if(v->csp>=D3_MAX_CALL)d3_vmfail(v,"call stack overflow");else{v->calls[v->csp++]=pc;pc=i->target;}break;case D3_RET:if(v->csp<=0)return 1;else pc=v->calls[--v->csp];break;case D3_HALT:return 1;
  case D3_PEEK8:a=d3_pop(v);d3_push(v,*(volatile d_u8*)(d_u64)a);break;case D3_PEEK16:a=d3_pop(v);d3_push(v,*(volatile d_u16*)(d_u64)a);break;case D3_PEEK32:a=d3_pop(v);d3_push(v,*(volatile d_u32*)(d_u64)a);break;case D3_PEEK64:a=d3_pop(v);d3_push(v,*(volatile d_u64*)(d_u64)a);break;
  case D3_POKE8:b=d3_pop(v);a=d3_pop(v);*(volatile d_u8*)(d_u64)a=(d_u8)b;d3_push(v,b);break;case D3_POKE16:b=d3_pop(v);a=d3_pop(v);*(volatile d_u16*)(d_u64)a=(d_u16)b;d3_push(v,b);break;case D3_POKE32:b=d3_pop(v);a=d3_pop(v);*(volatile d_u32*)(d_u64)a=(d_u32)b;d3_push(v,b);break;case D3_POKE64:b=d3_pop(v);a=d3_pop(v);*(volatile d_u64*)(d_u64)a=(d_u64)b;d3_push(v,b);break;
  case D3_ALLOC:a=d3_pop(v);d3_push(v,(d_i64)(d_u64)(h&&h->alloc?h->alloc(h->ctx,(d_u64)a):0));break;case D3_FREE:a=d3_pop(v);if(h&&h->free_)h->free_(h->ctx,(void*)(d_u64)a);d3_push(v,0);break;
  case D3_API:{d_u64 sym=(d_u64)d3_pop(v),dll=(d_u64)d3_pop(v);d3_push(v,(d_i64)(h&&h->api?h->api(h->ctx,(const char*)dll,(const char*)sym):0));}break;
  case D3_NATIVE:{int n=i->a;d_u64 aa[6]={0,0,0,0,0,0};for(int k=n-1;k>=0;k--)aa[k]=(d_u64)d3_pop(v);d_u64 fn=(d_u64)d3_pop(v);d3_push(v,(d_i64)d3_native_call(fn,n,aa));}break;
  case D3_UPUSH:a=d3_pop(v);if(v->usp>=D3_MAX_USTACK)d3_vmfail(v,"user stack overflow");else{v->ustack[v->usp++]=a;d3_push(v,a);}break;case D3_UPOP:if(v->usp<=0)d3_vmfail(v,"user stack underflow");else d3_push(v,v->ustack[--v->usp]);break;
  case D3_ASM:{int n=i->n;if(!h||!h->alloc||!h->free_){d3_push(v,0);break;}d_u8*m=(d_u8*)h->alloc(h->ctx,(d_u64)n+16);if(!m){d3_push(v,0);break;}for(int k=0;k<n;k++)m[k]=i->raw[k];if(!n||m[n-1]!=0xC3)m[n++]=0xC3;d_u64 r=((d_u64(D3_MS*)(void))m)();h->free_(h->ctx,m);d3_push(v,(d_i64)r);}break;
  default:d3_vmfail(v,"bad opcode");break;
 }}
 if(steps>=maxsteps)d3_vmfail(v,"step limit");return v->error?0:1;
}
static int d3_run(D3Program*p,D3Host*h,D3VM*v,int maxsteps){d3_vmreset(v);return d3_exec(p,h,v,0,maxsteps);}

#endif
