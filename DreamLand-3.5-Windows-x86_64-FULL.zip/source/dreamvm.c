#include "dream3_core.h"
typedef d_u32 DWORD; typedef d_i32 BOOL; typedef d_u32 UINT; typedef void* HANDLE; typedef void* HMODULE;
#define MS D3_MS
extern HANDLE MS CreateFileA(const char*,DWORD,DWORD,void*,DWORD,DWORD,HANDLE);
extern BOOL MS ReadFile(HANDLE,void*,DWORD,DWORD*,void*); extern BOOL MS WriteFile(HANDLE,const void*,DWORD,DWORD*,void*); extern BOOL MS CloseHandle(HANDLE);
extern HANDLE MS GetStdHandle(DWORD); extern char* MS GetCommandLineA(void); extern HMODULE MS LoadLibraryA(const char*); extern void* MS GetProcAddress(HMODULE,const char*);
extern void* MS VirtualAlloc(void*,d_u64,DWORD,DWORD); extern BOOL MS VirtualFree(void*,d_u64,DWORD); extern void MS ExitProcess(UINT);
#define STD_OUTPUT_HANDLE ((DWORD)-11)
#define GENERIC_READ 0x80000000u
#define FILE_SHARE_READ 1
#define OPEN_EXISTING 3
#define FILE_ATTRIBUTE_NORMAL 0x80
#define INVALID_HANDLE_VALUE ((HANDLE)(d_i64)-1)
#define MEM_COMMIT 0x1000
#define MEM_RESERVE 0x2000
#define MEM_RELEASE 0x8000
#define PAGE_EXECUTE_READWRITE 0x40
static HANDLE ho; static D3Program prog;
static void out(void*c,const char*s){(void)c;DWORD w=0;WriteFile(ho,s,(DWORD)d3_len(s),&w,0);}static void putc_(void*c,char q){(void)c;DWORD w=0;WriteFile(ho,&q,1,&w,0);}
static void* alloc_(void*c,d_u64 n){(void)c;return VirtualAlloc(0,n,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);}static void free_(void*c,void*p){(void)c;if(p)VirtualFree(p,0,MEM_RELEASE);}
static d_u64 api_(void*c,const char*d,const char*n){(void)c;HMODULE m=0;if(d&&d[0])m=LoadLibraryA(d);else{m=LoadLibraryA("ucrtbase.dll");if(m){void*f=GetProcAddress(m,n);if(f)return (d_u64)f;}m=LoadLibraryA("msvcrt.dll");}return m?(d_u64)GetProcAddress(m,n):0;}
static void arg(char*out){char*p=GetCommandLineA();while(*p&&*p!=' ')p++;while(*p==' ')p++;int q=0;if(*p=='"'){q=1;p++;}char*d=out;while(*p&&((q&&*p!='"')||(!q&&*p!=' ')))*d++=*p++;*d=0;}
int dreamvm_main(void){
 ho=GetStdHandle(STD_OUTPUT_HANDLE);char fn[260];arg(fn);if(!fn[0])d3_copy(fn,"dream.dvm",260);HANDLE f=CreateFileA(fn,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);if(f==INVALID_HANDLE_VALUE){out(0,"dreamvm: cannot open image\r\n");ExitProcess(2);}DWORD r=0;D3Head h;ReadFile(f,&h,sizeof(h),&r,0);if(h.magic[0]!='D'||h.magic[1]!='R'||h.magic[2]!='M'||h.magic[3]!='3'||h.version!=3||h.ncode>D3_MAX_CODE){out(0,"dreamvm: bad DRM3 image\r\n");ExitProcess(3);}prog.ncode=(int)h.ncode;prog.nvars=(int)h.nvars;ReadFile(f,prog.code,(DWORD)(prog.ncode*sizeof(D3Ins)),&r,0);CloseHandle(f);D3Host host={out,putc_,alloc_,free_,api_,0};D3VM vm;if(!d3_run(&prog,&host,&vm,100000000)){out(0,"\r\ndreamvm: ");out(0,vm.error_text);out(0,"\r\n");ExitProcess(4);}ExitProcess(0);return 0;
}
