/*
 DREAM LAND 3.5 // DREAM C // 53RD CENTURY
 Native Win32 IDE + compiler + VM. No CRT. No console host.
 Exact Win64 LLP64 ABI widths: no host-long leakage.
*/
#include "dream3_core.h"
#include "dream_metal.h"
#include "dream_cbridge.h"

typedef signed short d_i16; typedef d_u32 DWORD; typedef d_i32 LONG; typedef d_i32 BOOL; typedef d_u32 UINT;
typedef d_u64 ULONG_PTR; typedef d_u64 WPARAM; typedef d_i64 LPARAM; typedef d_i64 LRESULT;
typedef d_u16 ATOM; typedef d_u32 COLORREF;
typedef void* HANDLE; typedef void* HWND; typedef void* HINSTANCE; typedef void* HMODULE;
typedef void* HICON; typedef void* HCURSOR; typedef void* HBRUSH; typedef void* HMENU;
typedef void* HDC; typedef void* HFONT; typedef void* HGDIOBJ; typedef void* HBITMAP;
#define MS D3_MS
extern HMODULE MS LoadLibraryA(const char*); extern void* MS GetProcAddress(HMODULE,const char*);
extern HANDLE MS CreateFileA(const char*,DWORD,DWORD,void*,DWORD,DWORD,HANDLE);
extern BOOL MS ReadFile(HANDLE,void*,DWORD,DWORD*,void*); extern BOOL MS WriteFile(HANDLE,const void*,DWORD,DWORD*,void*); extern BOOL MS CloseHandle(HANDLE);
extern void* MS VirtualAlloc(void*,d_u64,DWORD,DWORD); extern BOOL MS VirtualFree(void*,d_u64,DWORD); extern void MS ExitProcess(UINT);

#define WM_DESTROY 2
#define WM_PAINT 15
#define WM_ERASEBKGND 20
#define WM_CHAR 258
#define WM_KEYDOWN 256
#define WM_SIZE 5
#define WM_TIMER 0x0113
#define WM_LBUTTONDOWN 0x0201
#define WM_NCLBUTTONDOWN 0x00A1
#define HTCAPTION 2
#define VK_ESCAPE 27
#define VK_F1 0x70
#define VK_F2 0x71
#define VK_F5 0x74
#define VK_F6 0x75
#define VK_LEFT 0x25
#define VK_UP 0x26
#define VK_RIGHT 0x27
#define VK_DOWN 0x28
#define VK_HOME 0x24
#define VK_END 0x23
#define WS_POPUP 0x80000000u
#define WS_THICKFRAME 0x00040000u
#define WS_SYSMENU 0x00080000u
#define WS_MINIMIZEBOX 0x00020000u
#define WS_MAXIMIZEBOX 0x00010000u
#define PATCOPY 0x00F00021u
#define SW_SHOW 5
#define CS_HREDRAW 2
#define CS_VREDRAW 1
#define IDC_ARROW ((const char*)32512)
#define CW_USEDEFAULT ((d_i32)0x80000000u)
#define BLACKNESS 0x00000042u
#define SRCCOPY 0x00CC0020u
#define TRANSPARENT 1
#define FW_NORMAL 400
#define DEFAULT_CHARSET 1
#define OUT_DEFAULT_PRECIS 0
#define CLIP_DEFAULT_PRECIS 0
#define DEFAULT_QUALITY 0
#define FIXED_PITCH 1
#define FF_MODERN 48
#define GENERIC_READ 0x80000000u
#define GENERIC_WRITE 0x40000000u
#define FILE_SHARE_READ 1
#define FILE_SHARE_WRITE 2
#define OPEN_EXISTING 3
#define CREATE_ALWAYS 2
#define FILE_ATTRIBUTE_NORMAL 0x80
#define INVALID_HANDLE_VALUE ((HANDLE)(d_i64)-1)
#define MEM_COMMIT 0x1000
#define MEM_RESERVE 0x2000
#define MEM_RELEASE 0x8000
#define PAGE_EXECUTE_READWRITE 0x40

typedef struct { LONG left,top,right,bottom; } RECT;
typedef struct { LONG x,y; } POINT;
typedef struct { HWND hwnd; UINT message; WPARAM wParam; LPARAM lParam; DWORD time; POINT pt; DWORD lPrivate; } MSG;
typedef struct { HDC hdc; BOOL fErase; RECT rcPaint; BOOL fRestore; BOOL fIncUpdate; d_u8 rgbReserved[32]; } PAINTSTRUCT;
typedef LRESULT (MS *WNDPROC)(HWND,UINT,WPARAM,LPARAM);
typedef struct {UINT style;WNDPROC lpfnWndProc;d_i32 cbClsExtra,cbWndExtra;HINSTANCE hInstance;HICON hIcon;HCURSOR hCursor;HBRUSH hbrBackground;const char*lpszMenuName;const char*lpszClassName;} WNDCLASSA;
_Static_assert(sizeof(DWORD)==4,"DWORD"); _Static_assert(sizeof(LONG)==4,"LONG"); _Static_assert(sizeof(RECT)==16,"RECT"); _Static_assert(sizeof(POINT)==8,"POINT"); _Static_assert(sizeof(MSG)==48,"MSG"); _Static_assert(sizeof(PAINTSTRUCT)==72,"PAINTSTRUCT"); _Static_assert(sizeof(WNDCLASSA)==72,"WNDCLASSA");

typedef ATOM (MS *pRegisterClassA)(const WNDCLASSA*); typedef HWND (MS *pCreateWindowExA)(DWORD,const char*,const char*,DWORD,d_i32,d_i32,d_i32,d_i32,HWND,HMENU,HINSTANCE,void*);
typedef BOOL (MS *pShowWindow)(HWND,d_i32); typedef BOOL (MS *pUpdateWindow)(HWND); typedef d_i32 (MS *pGetMessageA)(MSG*,HWND,UINT,UINT); typedef BOOL (MS *pTranslateMessage)(const MSG*);
typedef LRESULT (MS *pDispatchMessageA)(const MSG*); typedef LRESULT (MS *pDefWindowProcA)(HWND,UINT,WPARAM,LPARAM); typedef void (MS *pPostQuitMessage)(d_i32); typedef BOOL (MS *pInvalidateRect)(HWND,const RECT*,BOOL);
typedef HDC (MS *pBeginPaint)(HWND,PAINTSTRUCT*); typedef BOOL (MS *pEndPaint)(HWND,const PAINTSTRUCT*); typedef BOOL (MS *pGetClientRect)(HWND,RECT*); typedef HCURSOR (MS *pLoadCursorA)(HINSTANCE,const char*);
typedef LRESULT (MS *pSendMessageA)(HWND,UINT,WPARAM,LPARAM); typedef BOOL (MS *pDestroyWindow)(HWND); typedef d_u64 (MS *pSetTimer)(HWND,d_u64,UINT,void*); typedef BOOL (MS *pKillTimer)(HWND,d_u64); typedef BOOL (MS *pCreateCaret)(HWND,HBITMAP,d_i32,d_i32); typedef BOOL (MS *pShowCaret)(HWND); typedef BOOL (MS *pHideCaret)(HWND); typedef BOOL (MS *pDestroyCaret)(void); typedef BOOL (MS *pSetCaretPos)(d_i32,d_i32);
typedef HDC (MS *pCreateCompatibleDC)(HDC); typedef BOOL (MS *pDeleteDC)(HDC); typedef HBITMAP (MS *pCreateCompatibleBitmap)(HDC,d_i32,d_i32); typedef HGDIOBJ (MS *pSelectObject)(HDC,HGDIOBJ);
typedef BOOL (MS *pDeleteObject)(HGDIOBJ); typedef BOOL (MS *pBitBlt)(HDC,d_i32,d_i32,d_i32,d_i32,HDC,d_i32,d_i32,DWORD); typedef COLORREF (MS *pSetTextColor)(HDC,COLORREF); typedef d_i32 (MS *pSetBkMode)(HDC,d_i32);
typedef BOOL (MS *pTextOutA)(HDC,d_i32,d_i32,const char*,d_i32); typedef BOOL (MS *pPatBlt)(HDC,d_i32,d_i32,d_i32,d_i32,DWORD); typedef HFONT (MS *pCreateFontA)(d_i32,d_i32,d_i32,d_i32,d_i32,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,const char*);
typedef HBRUSH (MS *pCreateSolidBrush)(COLORREF); typedef HINSTANCE (MS *pGetModuleHandleA)(const char*);

static pRegisterClassA RegisterClassA_;static pCreateWindowExA CreateWindowExA_;static pShowWindow ShowWindow_;static pUpdateWindow UpdateWindow_;static pGetMessageA GetMessageA_;static pTranslateMessage TranslateMessage_;static pDispatchMessageA DispatchMessageA_;static pDefWindowProcA DefWindowProcA_;static pPostQuitMessage PostQuitMessage_;static pInvalidateRect InvalidateRect_;static pBeginPaint BeginPaint_;static pEndPaint EndPaint_;static pGetClientRect GetClientRect_;static pLoadCursorA LoadCursorA_;static pSendMessageA SendMessageA_;static pDestroyWindow DestroyWindow_;static pSetTimer SetTimer_;static pKillTimer KillTimer_;static pCreateCaret CreateCaret_;static pShowCaret ShowCaret_;static pHideCaret HideCaret_;static pDestroyCaret DestroyCaret_;static pSetCaretPos SetCaretPos_;
static pCreateCompatibleDC CreateCompatibleDC_;static pDeleteDC DeleteDC_;static pCreateCompatibleBitmap CreateCompatibleBitmap_;static pSelectObject SelectObject_;static pDeleteObject DeleteObject_;static pBitBlt BitBlt_;static pSetTextColor SetTextColor_;static pSetBkMode SetBkMode_;static pTextOutA TextOutA_;static pPatBlt PatBlt_;static pCreateFontA CreateFontA_;static pCreateSolidBrush CreateSolidBrush_;static pGetModuleHandleA GetModuleHandleA_;

static HWND g_hwnd;static HFONT g_font;static HBRUSH g_green,g_white,g_black;
static char source[262144];static d_i32 source_len,cur,view_line;
static char prompt[512];static d_i32 prompt_len,mode; /* 0 Dream>, 1 editor */
static char output[32768];static d_i32 output_len;
static char status[256]="DRM3:READY // CBRIDGE:READY // METAL:READY // ASM:GATE-OPEN";
static d_u64 timer_id=53;static d_i32 line_numbers=0,sparkle=1,hud=1;static d_u32 twinkle_phase=0;static D3Program prog;static DCB bridge;static d_u8 metal_buf[DM_MAX],coff_buf[DM_MAX+128];

static void repaint(void){if(g_hwnd)InvalidateRect_(g_hwnd,0,0);}
static void out_clear(void){output_len=0;output[0]=0;}
static void out_add(const char*s){int n=d3_len(s);if(output_len+n>=(int)sizeof(output)-1)n=(int)sizeof(output)-1-output_len;for(int i=0;i<n;i++)output[output_len++]=s[i];output[output_len]=0;}
static void out_i(d_i64 v){char b[40];d3_i64str(v,b);out_add(b);}
static void vm_out(void*c,const char*s){(void)c;out_add(s);}static void vm_putc(void*c,char q){(void)c;char x[2]={q,0};out_add(x);}
static void* vm_alloc(void*c,d_u64 n){(void)c;return VirtualAlloc(0,n? n:1,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);}static void vm_free(void*c,void*p){(void)c;if(p)VirtualFree(p,0,MEM_RELEASE);}
static d_u64 vm_api(void*c,const char*dll,const char*name){(void)c;HMODULE m=0;if(dll&&dll[0])m=LoadLibraryA(dll);else{m=LoadLibraryA("ucrtbase.dll");if(m){void*f=GetProcAddress(m,name);if(f)return (d_u64)f;}m=LoadLibraryA("msvcrt.dll");}return m?(d_u64)GetProcAddress(m,name):0;}
static D3Host host={vm_out,vm_putc,vm_alloc,vm_free,vm_api,0};

static void file_save(void){HANDLE f=CreateFileA("dream.dc",GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);if(f==INVALID_HANDLE_VALUE){out_add("SAVE FAILED\n");return;}DWORD w=0;WriteFile(f,source,(DWORD)source_len,&w,0);CloseHandle(f);out_add("SAVE OK // dream.dc\n");}
static void file_load(void){HANDLE f=CreateFileA("dream.dc",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);if(f==INVALID_HANDLE_VALUE){out_add("LOAD // no dream.dc\n");return;}DWORD r=0;ReadFile(f,source,(DWORD)sizeof(source)-1,&r,0);CloseHandle(f);source_len=(int)r;source[source_len]=0;cur=source_len;view_line=0;out_add("LOAD OK // dream.dc\n");}
static int compile_now(void){if(!dcb_prepare(&bridge,source)){out_add("BRIDGE ERROR // ");out_add(bridge.error);out_add("\n");d3_copy(status,"CBRIDGE:FAULT // man cimport",256);return 0;}if(!d3_compile(&prog,bridge.dream)){out_add("COMPILE ERROR // line ");out_i(prog.error_line);out_add(" // ");out_add(prog.error);out_add("\n");d3_copy(status,"COMPILER:FAULT // man lang",256);return 0;}out_add("COMPILE OK // ");out_i(prog.ncode);out_add(" bytecode ops // ");out_i(prog.nvars);out_add(" vars");if(bridge.next){out_add(" // C EXTERNS ");out_i(bridge.next);}out_add("\n");d3_copy(status,"COMPILER:OK // VM:READY // CBRIDGE:READY // ASM:GATE-OPEN",256);return 1;}
static void metal_now(int coff){out_clear();char er[160];int n=0;if(!dm_extract(source,metal_buf,DM_MAX,&n,er,160)){out_add("METAL ERROR // ");out_add(er);out_add("\n");repaint();return;}const d_u8*data=metal_buf;int bytes=n;const char*fn="dream.bin";if(coff){bytes=dm_coff(metal_buf,n,coff_buf,DM_MAX+128);if(!bytes){out_add("COFF ERROR // image too large\n");repaint();return;}data=coff_buf;fn="dream.obj";}HANDLE f=CreateFileA(fn,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);if(f==INVALID_HANDLE_VALUE){out_add("METAL WRITE FAILED\n");repaint();return;}DWORD w=0;WriteFile(f,data,(DWORD)bytes,&w,0);CloseHandle(f);out_add(coff?"OBJ OK // dream.obj // entry: dream_entry\n":"METAL OK // dream.bin // flat machine image\n");out_i(bytes);out_add(" bytes\n");repaint();}
static void cgen_now(int build){out_clear();if(!compile_now()){repaint();return;}int cap=8*1024*1024;char*gen=(char*)VirtualAlloc(0,(d_u64)cap,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);if(!gen){out_add("CBRIDGE // cannot allocate generator buffer\n");repaint();return;}int n=dcb_generate_c(&bridge,&prog,gen,cap);if(!n){VirtualFree(gen,0,MEM_RELEASE);out_add("CBRIDGE // C generation failed\n");repaint();return;}HANDLE f=CreateFileA("dream_native.c",GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);if(f==INVALID_HANDLE_VALUE){VirtualFree(gen,0,MEM_RELEASE);out_add("CBRIDGE // cannot write dream_native.c\n");repaint();return;}DWORD w=0;WriteFile(f,gen,(DWORD)n,&w,0);CloseHandle(f);VirtualFree(gen,0,MEM_RELEASE);out_add("CGEN OK // dream_native.c // inherits ");out_i(bridge.nimports);out_add(" headers // ");out_i(bridge.next);out_add(" externs\n");if(build){char cmd[16384];if(!dcb_build_command(&bridge,"dream_native.c","dream_native.exe",cmd,sizeof(cmd),"gcc")){out_add("CBUILD // command too large\n");repaint();return;}HMODULE k=LoadLibraryA("kernel32.dll");typedef UINT (MS *PWE)(const char*,UINT);PWE we=(PWE)GetProcAddress(k,"WinExec");if(!we){out_add("CBUILD // WinExec unavailable\n");repaint();return;}char alt[16384];dcb_build_command(&bridge,"dream_native.c","dream_native.exe",alt,sizeof(alt),"clang");char full[16384];int fn=0;dcb_cat(full,&fn,sizeof(full),"cmd.exe /c (");dcb_cat(full,&fn,sizeof(full),cmd);dcb_cat(full,&fn,sizeof(full),") || (");dcb_cat(full,&fn,sizeof(full),alt);dcb_cat(full,&fn,sizeof(full),") > dream_cbuild.log 2>&1");we(full,0);out_add("CBUILD LAUNCHED // GCC then Clang fallback // dream_native.exe // log: dream_cbuild.log\n");d3_copy(status,"CBRIDGE:BUILDING // DREAM REMAINS LIVE",256);}repaint();}
static void run_now(void){out_clear();if(!compile_now()){repaint();return;}D3VM vm;if(!d3_run(&prog,&host,&vm,100000000)){out_add("VM FAULT // ");out_add(vm.error_text);out_add("\n");d3_copy(status,"VM:FAULT // DREAM >",256);}else{out_add("\nRUN COMPLETE // DREAM >\n");d3_copy(status,"RUN:COMPLETE // COMPILER:OK // VM:READY",256);}mode=0;repaint();}
static void build_now(void){out_clear();if(!compile_now()){repaint();return;}HANDLE f=CreateFileA("dream.dvm",GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);if(f==INVALID_HANDLE_VALUE){out_add("BUILD FAILED // cannot write dream.dvm\n");return;}D3Head h={{'D','R','M','3'},3,(d_u32)prog.ncode,(d_u32)prog.nvars,0};DWORD w=0;WriteFile(f,&h,sizeof(h),&w,0);WriteFile(f,prog.code,(DWORD)(prog.ncode*sizeof(D3Ins)),&w,0);CloseHandle(f);out_add("BUILD OK // dream.dvm\n");d3_copy(status,"BUILD:OK // DRM3 IMAGE READY",256);repaint();}

static const char* MAN=
"DREAM MAN 3.5 // MAP\n"
"list          all commands + topics\n"
"search TERM   search command/topic names\n"
"man TOPIC     two-line micro-manual\n"
"man example   Dream C example program\n"
"man greetz    makers, support, links\n"
"edit/run/build/save/load/new/clear\n"
"metal/obj/cgen/cbuild\n"
"lines/sparkle/calm/hud\n"
"lang/ops/asm/about\n"
"F1 MAN | F2 EDIT | F5 RUN | F6 BUILD | ESC DREAM >\n";
static const char* LANG=
"DREAM C 3.5 // MINIMAL COMPLETE SYSTEMS LANGUAGE + CBRIDGE\n"
"var/int/ptr x = expr;     64-bit value/pointer\n"
"x = expr;                 assignment\n"
"print(a,\"text\",b);      output values + strings\n"
"macro NAME = VALUE;       tiny compile-time number/string constant\n"
"ANSI: \\e is ESC           e.g. macro G=\"\\e[92m\";\n"
"println(...); putc(x);    text/byte output\n"
"label: goto label;        branches / loops\n"
"if expr goto label;       conditional branch\n"
"call label; return;       subroutines\n"
"halt; / end;              stop\n"
"alloc/free                raw executable memory\n"
"peek8/16/32/64(addr)      raw reads\n"
"poke8/16/32/64(addr,val)  raw writes\n"
"api(\"dll\",\"symbol\")   resolve any Windows API\n"
"native(fn,a..f)           call any Win64 ABI function (0..6 args)\n"
"push(x) / pop()           explicit user stack\n"
"asm { B8 2A 00 00 00 C3 } raw x64 expression; returns RAX\n"
"operators: + - * / % << >> & | ^ ~ ! && || == != < <= > >=\n"
"Dream: %% weave | ?= match | <-> resonance | ->> native-flow | @> materialize64\n"
"C INHERITANCE: cimport <h>; | extern c [\"dll\"] RET fn(TYPES); | link \"lib/flag\";\n"
"C ESCAPE: c { arbitrary C helpers/macros/types } | cflag \"compiler flag\"; | export c label;\n"
"CBUILD: Dream bytecode + typed C wrappers + real GCC/Clang headers/libraries -> native executable\n"
"FREESTANDING: metal -> dream.bin | obj -> x64 COFF dream.obj / symbol dream_entry\n"
"METAL DIRECTIVES: asm { HEX } | byte/word/dword/qword N | align N | pad OFFSET [FILL]\n";
static const char* TOPICS[] = {"man","list","search","example","greetz","macro","ansi","edit","run","build","metal","obj","cgen","cbuild","save","load","clear","lines","sparkle","calm","hud","support","lang","ops","asm","print","println","putc","var","if","goto","call","return","halt","alloc","free","peek","poke","api","native","push","pop","cimport","extern","link","cflag","cblock","export","about",0};
static const char* EXAMPLE=
"// DREAM C 3.5 // example\n"
"cimport <stdio.h>;\n"
"extern c i32 puts(cstr);\n"
"macro LIMIT = 8;\n"
"var x = 0;\n"
"loop:\n"
"print(x, \"  \" );\n"
"x = x + 1;\n"
"if x < LIMIT goto loop;\n"
"puts(\"WELCOME TO DREAMLAND\");\n"
"var answer = asm { B8 2A 00 00 00 C3 };\n"
"println(answer);\n"
"halt;\n";
static int has_sub(const char*s,const char*q){int n=d3_len(s),m=d3_len(q);if(m<=0)return 1;for(int i=0;i<=n-m;i++){int ok=1;for(int j=0;j<m;j++){char a=s[i+j],b=q[j];if(a>='A'&&a<='Z')a=(char)(a+32);if(b>='A'&&b<='Z')b=(char)(b+32);if(a!=b){ok=0;break;}}if(ok)return 1;}return 0;}
static void list_now(void){out_add("COMMANDS // TOPICS\n");for(int i=0;TOPICS[i];i++){out_add(TOPICS[i]);out_add((i%7==6)?"\n":"  ");}out_add("\n\nman TOPIC // explain one\nsearch TERM // find one\n");}
static void search_now(const char*q){int hits=0;out_add("SEARCH // ");out_add(q);out_add("\n");for(int i=0;TOPICS[i];i++)if(has_sub(TOPICS[i],q)){out_add("  ");out_add(TOPICS[i]);out_add("\n");hits++;}if(!hits)out_add("NO MATCHES // try list\n");}
static void greetz_now(void){
 out_add("GREETZ // DREAM LAND\n");
 out_add("MADE BY LUMINOSITY + GPTEUS THE ELECTRIC SPRITE\n");
 out_add("SUPPORT // CASH APP $UNIXARCADE\n\n");
 out_add("LIVEJOURNAL // https://luminosity.livejournal.com\n");
 out_add("FORGE AI OS BY LUMINOSITY // https://luminosity.gumroad.com/l/fyosxi\n");
 out_add("GUMROAD // https://luminosity.gumroad.com\n");
 out_add("GUMROAD PRODUCTS // https://gumroad.com/products\n");
 out_add("GITHUB // https://github.com/unixarcade\n");
 out_add("GOODREADS // https://www.goodreads.com/review/list/1550470-matthew-kowalski?ref=nav_mybooks&shelf=books-i-have-written\n");
}
static void support_now(void){greetz_now();}

static void man_topic(const char*n){
 if(d3_eq(n,"example")){out_add("example // a compact Dream C program showing C inheritance, looping, output, and raw asm.\nCopy/adapt it when you want a known-good seed without putting demo code on the landing screen.\n\n");out_add(EXAMPLE);}
 else if(d3_eq(n,"greetz")||d3_eq(n,"support")){out_add("greetz // makers, support, and the public constellation around Dream Land.\nIt keeps commerce/credits out of the main screen while making them one command away.\n\n");greetz_now();}
 else if(d3_eq(n,"man"))out_add("man TOPIC // show a two-line micro-manual for one command, operator, or language gate.\nUse list to see the whole surface area and search TERM to find things when your memory outruns your prompt.\n");
 else if(d3_eq(n,"list"))out_add("list // show the whole Dream command/topic surface in one compact page.\nIt is the fast map when you want to see what exists before drilling into man TOPIC.\n");
 else if(d3_eq(n,"search"))out_add("search TERM // search commands/topics by case-insensitive substring.\nUse it when you remember part of a name but not the exact spell.\n");
 else if(d3_eq(n,"macro"))out_add("macro NAME = VALUE // define one compile-time number or string constant; expansion becomes a normal Dream literal.\nIt is deliberately not a preprocessor: sixty-four tiny constants give aliases, flags, addresses, and ANSI styles without macro-language bloat.\n");
 else if(d3_eq(n,"ansi"))out_add("ANSI // Dream strings understand \\e as the ESC byte, so terminal/native output can use standard escape sequences directly.\nExample: macro G = \"\\e[92m\"; print(G,\"green\",\"\\e[0m\"); Dream Land itself keeps its native GDI palette.\n");
 else if(d3_eq(n,"run"))out_add("run // compile the source once into DRM3 bytecode, then execute it in the embedded VM.\nExpressions are already opcodes at runtime; no parser or external compiler sits in the loop.\n");
 else if(d3_eq(n,"build"))out_add("build // compile the current source into portable dream.dvm bytecode.\nRun that image with dreamvm; it keeps the hosted Dream program separate from the editor.\n");
 else if(d3_eq(n,"metal"))out_add("metal // extract asm blocks plus byte/word/dword/qword/align/pad into flat dream.bin.\nThis is the freestanding path for boot code, kernels, firmware payloads, ROM images, and raw machine artifacts.\n");
 else if(d3_eq(n,"obj"))out_add("obj // emit the same metal payload as an x86-64 COFF object named dream.obj.\nThe object exports dream_entry, so LLD can link it into EFI, PE, native subsystem, or /driver images.\n");
 else if(d3_eq(n,"asm"))out_add("asm { HEX } // hosted mode executes raw x64 bytes and returns RAX; metal mode emits them verbatim.\nUse it when Dream syntax should disappear and the processor instruction stream should be the language.\n");
 else if(d3_eq(n,"print"))out_add("print(a,b,...) // write integer and string values without adding a newline.\nprintln adds CRLF; putc emits one byte/character for precise output protocols.\n");
 else if(d3_eq(n,"var")||d3_eq(n,"int")||d3_eq(n,"ptr"))out_add("var/int/ptr name = expr // create one 64-bit Dream cell; the three spellings are intentionally equivalent.\nA cell can hold an integer, address, function pointer, handle, bitfield, or whatever meaning your program assigns.\n");
 else if(d3_eq(n,"if"))out_add("if expr goto label // branch when expr is nonzero.\nCombined with labels and assignment this is enough for loops, state machines, and arbitrary control flow.\n");
 else if(d3_eq(n,"goto"))out_add("goto label // jump directly to a compiled label.\nDream keeps this primitive because it is small, predictable, and maps cleanly to machine control flow.\n");
 else if(d3_eq(n,"call"))out_add("call label // push a Dream return address and enter a subroutine label.\nreturn/ret pops that address; use the user stack when you also need explicit data passing.\n");
 else if(d3_eq(n,"return")||d3_eq(n,"ret"))out_add("return // leave the current Dream subroutine and resume after its call.\nAt top level it ends execution cleanly, so a tiny program can use return instead of halt.\n");
 else if(d3_eq(n,"halt")||d3_eq(n,"end"))out_add("halt // stop the Dream VM immediately.\nIn freestanding metal code use asm to choose the processor-level ending you actually want, such as HLT or RET.\n");
 else if(d3_eq(n,"alloc")||d3_eq(n,"free"))out_add("alloc(n) / free(p) // acquire or release raw executable memory from the current host.\nThe returned address is an ordinary 64-bit Dream value and can be read, written, called, or materialized into.\n");
 else if(d3_eq(n,"peek")||d3_eq(n,"peek64"))out_add("peek8/16/32/64(addr) // read raw memory at an address using the requested width.\nNo object model intervenes: addresses are numbers and bad addresses have the same consequences as native systems code.\n");
 else if(d3_eq(n,"poke")||d3_eq(n,"poke64"))out_add("poke8/16/32/64(addr,val) // write raw memory at an address using the requested width.\nUse @> for the compact 64-bit materialize form: value @> address.\n");
 else if(d3_eq(n,"api"))out_add("api(\"dll\",\"symbol\") // resolve a Windows DLL export and return its function address.\nIt is the bridge from tiny Dream syntax to the entire exposed Win32/NT user-mode API surface.\n");
 else if(d3_eq(n,"native"))out_add("native(fn,a..f) // call a Win64 function pointer with zero through six 64-bit arguments.\nPair with api(), raw addresses, or generated machine code to cross the language boundary with almost no ceremony.\n");
 else if(d3_eq(n,"push")||d3_eq(n,"pop"))out_add("push(x) / pop() // manipulate Dream's explicit user data stack.\nIt is separate from expression and return stacks, making compact stack-language patterns possible without hidden coupling.\n");
 else if(d3_eq(n,"ops"))out_add("%% weave | ?= match | <-> resonance/XOR | ->> native one-argument flow | @> materialize64.\nThe ordinary operator set also includes arithmetic, shifts, bitwise logic, comparisons, and boolean logic with precedence.\n");
 else if(d3_eq(n,"cimport"))out_add("cimport <header.h>; // pass a real C header to the native C bridge compiler.\nDream never parses its macro jungle; GCC/Clang does, so decades of typedefs, macros, structs, and declarations remain somebody else's solved problem.\n");
 else if(d3_eq(n,"extern"))out_add("extern c [\"dll\"] RET fn(TYPES); // give Dream a typed scalar/pointer doorway to one C function.\nHosted F5 can resolve DLL exports; cbuild generates an ABI wrapper so linked/static C functions become ordinary Dream calls.\n");
 else if(d3_eq(n,"link"))out_add("link \"library-or-linker-flag\"; // append one library, import library, -l flag, or linker token to cbuild.\nUse it for SQLite, SDL, zlib, OpenSSL, your own .a/.lib, or any other library the chosen C toolchain can link.\n");
 else if(d3_eq(n,"cflag"))out_add("cflag \"compiler-flag\"; // append include paths, defines, CPU flags, or other native compiler options.\nIt keeps machine/toolchain policy outside Dream's grammar while still exposing the full compiler ecosystem when a library needs it.\n");
 else if(d3_eq(n,"cblock")||d3_eq(n,"c"))out_add("c { ... } // copy arbitrary C directly into the generated native translation unit without teaching Dream that syntax.\nUse it as the universal adapter for macros, variadics, struct-by-value APIs, callbacks, compiler intrinsics, or anything too weird for the tiny typed bridge.\n");
 else if(d3_eq(n,"export"))out_add("export c label; // expose a Dream label as a C-ABI symbol in generated native code.\nArguments arrive in Dream cells a0..a5 and the wrapper returns the Dream cell named result, making C-to-Dream calls possible too.\n");
 else if(d3_eq(n,"cgen"))out_add("cgen // generate dream_native.c containing compiled Dream bytecode plus all requested C headers and wrappers.\nIt is inspectable ordinary C: the inheritance bridge stays visible instead of hiding a second secret language inside Dream.\n");
 else if(d3_eq(n,"cbuild"))out_add("cbuild // cgen, then ask GCC to link Dream with every cimport/link/c block into dream_native.exe.\nIf GCC is absent use dreamcc-3.5 --cgen and compile the generated file with Clang or the C toolchain required by your library.\n");
 else if(d3_eq(n,"lines"))out_add("lines // toggle source line numbers without changing the source buffer.\nUse it when you want compiler-friendly coordinates or a cleaner field for visual work.\n");
 else if(d3_eq(n,"sparkle"))out_add("sparkle // toggle Dream's slow border twinkle; motion is sparse and never flashes the source field.\nUse calm for an immediate motion-free presentation while keeping every editing and compiler feature unchanged.\n");
 else if(d3_eq(n,"hud"))out_add("hud // toggle the single Dream telemetry line; there is no telemetry wall anymore.\nThe prompt, source, output, checker frame, compiler, and VM stay unchanged either way.\n");
 else if(d3_eq(n,"support"))out_add("support // show the maker card and support line inside Dream Land.\nIt credits Luminosity and Gpteus the electric sprite and shows Cash App $UNIXARCADE.\n");
 else if(d3_eq(n,"about"))out_add("about // show the current build identity and environment intent.\nUse greetz for makers/support; about stays technical and keeps the landing surface clean.\n");
 else if(d3_eq(n,"clear"))out_add("clear // HOME: return to canonical Dream Land and activate Dream > immediately.\nSource stays resident while prompt, mode, and transient output are reset to a clean landing state.\n");
 else if(d3_eq(n,"edit"))out_add("edit // enter the native Dream source field and put the white caret in code.\nArrows move, Ctrl-S saves, F5 runs, F6 builds, and Esc returns straight to Dream >.\n");
 else if(d3_eq(n,"lang"))out_add("lang // show the complete compact hosted + freestanding Dream language map.\nDream stays small by exposing control, memory, FFI, byte emission, COFF output, and raw x64 instead of cloning a huge standard library.\n");
 else out_add("NO MAN ENTRY // type man for the topic map\n");
}
static void command(void){prompt[prompt_len]=0;out_clear();
 if(d3_eq(prompt,"man")||d3_eq(prompt,"help"))out_add(MAN);
 else if(d3_eq(prompt,"list"))list_now();
 else if(prompt_len>7&&prompt[0]=='s'&&prompt[1]=='e'&&prompt[2]=='a'&&prompt[3]=='r'&&prompt[4]=='c'&&prompt[5]=='h'&&prompt[6]==' ')search_now(prompt+7);
 else if(prompt_len>4&&prompt[0]=='m'&&prompt[1]=='a'&&prompt[2]=='n'&&prompt[3]==' ')man_topic(prompt+4);
 else if(d3_eq(prompt,"lang"))out_add(LANG);
 else if(d3_eq(prompt,"ops"))out_add("%% WEAVE bits\n?= MATCH equality\n<-> RESONANCE XOR\n->> FLOW value through Win64 function pointer\n@> MATERIALIZE value into raw 64-bit address\n");
 else if(d3_eq(prompt,"asm"))man_topic("asm");
 else if(d3_eq(prompt,"metal"))metal_now(0);else if(d3_eq(prompt,"obj"))metal_now(1);else if(d3_eq(prompt,"cgen"))cgen_now(0);else if(d3_eq(prompt,"cbuild"))cgen_now(1);
 else if(d3_eq(prompt,"lines")){line_numbers=!line_numbers;out_add(line_numbers?"LINES // ON\n":"LINES // OFF\n");}
 else if(d3_eq(prompt,"sparkle")){sparkle=!sparkle;if(sparkle)SetTimer_(g_hwnd,timer_id,2300,0);else KillTimer_(g_hwnd,timer_id);out_add(sparkle?"SPARKLE // ON // LOW MOTION\n":"SPARKLE // OFF\n");}
 else if(d3_eq(prompt,"calm")){sparkle=0;KillTimer_(g_hwnd,timer_id);out_add("CALM // MOTION / FLAIR OFF\n");}
 else if(d3_eq(prompt,"hud")){hud=!hud;out_add(hud?"HUD // ON\n":"HUD // OFF\n");}
 else if(d3_eq(prompt,"greetz")||d3_eq(prompt,"support")){greetz_now();}
 else if(d3_eq(prompt,"edit")){mode=1;d3_copy(status,"EDIT // CTRL-S SAVE // F5 RUN // F6 BUILD // ESC DREAM >",256);}
 else if(d3_eq(prompt,"run"))run_now();else if(d3_eq(prompt,"build"))build_now();
 else if(d3_eq(prompt,"save"))file_save();else if(d3_eq(prompt,"load"))file_load();
 else if(d3_eq(prompt,"new")){source_len=cur=view_line=0;source[0]=0;mode=1;d3_copy(status,"NEW DREAM // EDIT",256);}
 else if(d3_eq(prompt,"clear")){mode=0;prompt_len=0;prompt[0]=0;out_clear();d3_copy(status,"DRM3:READY // CBRIDGE:READY // METAL:READY // ASM:GATE-OPEN",256);}
 else if(d3_eq(prompt,"about"))out_add("DREAM LAND 3.5 // DREAM C // NATIVE WIN32 // DRM3 + CBRIDGE\nEXACT WIN64 ABI // NO CONSOLE HOST // MEMORY + FFI + ASM GATES OPEN\n");
 else{out_add("UNKNOWN DREAM // ");out_add(prompt);out_add("\nTRY: man\n");}
 prompt_len=0;prompt[0]=0;repaint();}

static void cursor_key(int k){if(k==VK_LEFT&&cur>0)cur--;else if(k==VK_RIGHT&&cur<source_len)cur++;else if(k==VK_HOME){while(cur>0&&source[cur-1]!='\n')cur--;}else if(k==VK_END){while(cur<source_len&&source[cur]!='\n')cur++;}else if(k==VK_UP){int col=0,p=cur;while(p>0&&source[p-1]!='\n'){p--;col++;}if(p>0){p--;while(p>0&&source[p-1]!='\n')p--;cur=p;while(cur<source_len&&source[cur]!='\n'&&col--)cur++;}}else if(k==VK_DOWN){int col=0,p=cur;while(p>0&&source[p-1]!='\n'){p--;col++;}p=cur;while(p<source_len&&source[p]!='\n')p++;if(p<source_len)p++;cur=p;while(cur<source_len&&source[cur]!='\n'&&col--)cur++;}}
static int cursor_line(void){int n=0;for(int i=0;i<cur;i++)if(source[i]=='\n')n++;return n;}
static void keep_cursor_visible(int rows){int cl=cursor_line();if(cl<view_line)view_line=cl;if(cl>=view_line+rows)view_line=cl-rows+1;if(view_line<0)view_line=0;}
static void text(HDC dc,int x,int y,const char*s,int n){if(n<0)n=d3_len(s);TextOutA_(dc,x,y,s,n);}
static void draw_source(HDC dc,int x,int y,int rows){int pos=0,line=0,row=0;while(pos<source_len&&line<view_line){if(source[pos++]=='\n')line++;}while(row<rows&&pos<=source_len){char b[1024],num[24];int j=0;while(pos<source_len&&source[pos]!='\n'&&j<1000)b[j++]=source[pos++];if(pos<source_len&&source[pos]=='\n')pos++;b[j]=0;if(line_numbers){d3_i64str(line+1,num);SetTextColor_(dc,0x00007722);text(dc,x,y+row*18,num,-1);}SetTextColor_(dc,0x0000FF44);text(dc,x+(line_numbers?48:0),y+row*18,b,j);row++;line++;if(pos>=source_len)break;}}
static void draw_output(HDC dc,int x,int y,int rows){int pos=0,row=0;while(pos<output_len&&row<rows){char b[1024];int j=0;while(pos<output_len&&output[pos]!='\n'&&j<1000)b[j++]=output[pos++];if(pos<output_len&&output[pos]=='\n')pos++;b[j]=0;text(dc,x,y+row*18,b,j);row++;}}
static int output_rows_needed(void){if(!output_len)return 0;int n=0;for(int i=0;i<output_len;i++)if(output[i]=='\n')n++;if(output[output_len-1]!='\n')n++;if(n<2)n=2;if(n>22)n=22;return n;}

static LRESULT MS WndProc(HWND h,UINT m,WPARAM w,LPARAM l){
 if(m==WM_ERASEBKGND){RECT br;if(GetClientRect_&&PatBlt_&&GetClientRect_(h,&br))PatBlt_((HDC)w,0,0,br.right,br.bottom,BLACKNESS);return 1;}
 if(m==WM_LBUTTONDOWN){int x=(d_i16)(l&0xffff),y=(d_i16)((l>>16)&0xffff);RECT r;GetClientRect_(h,&r);if(y<56&&x>r.right-62){DestroyWindow_(h);return 0;}if(y<56){SendMessageA_(h,WM_NCLBUTTONDOWN,HTCAPTION,0);return 0;}}
 if(m==WM_DESTROY){if(KillTimer_)KillTimer_(h,timer_id);if(DestroyCaret_)DestroyCaret_();PostQuitMessage_(0);return 0;}
 if(m==WM_TIMER){twinkle_phase++;if(sparkle)repaint();return 0;}if(m==WM_SIZE){repaint();return 0;}
 if(m==WM_KEYDOWN){if(w==VK_F1){mode=0;out_clear();out_add(MAN);repaint();return 0;}if(w==VK_F2){mode=1;d3_copy(status,"EDIT // CTRL-S SAVE // F5 RUN // F6 BUILD // ESC DREAM >",256);repaint();return 0;}if(w==VK_F5){run_now();return 0;}if(w==VK_F6){build_now();return 0;}if(w==VK_ESCAPE){mode=0;d3_copy(status,"DREAM > // TYPE list OR man",256);repaint();return 0;}if(mode&& (w==VK_LEFT||w==VK_RIGHT||w==VK_UP||w==VK_DOWN||w==VK_HOME||w==VK_END)){cursor_key((int)w);repaint();return 0;}}
 if(m==WM_CHAR){char c=(char)w;if(!mode){if(c=='\r'){command();return 0;}if(c==8&&prompt_len>0){prompt[--prompt_len]=0;repaint();return 0;}if(c>=32&&prompt_len<510){prompt[prompt_len++]=c;prompt[prompt_len]=0;repaint();return 0;}}
  else{if(c==19){out_clear();file_save();repaint();return 0;}if(c==8&&cur>0){for(int i=cur-1;i<source_len;i++)source[i]=source[i+1];cur--;source_len--;repaint();return 0;}if((c>=32||c=='\r'||c=='\t')&&source_len<(int)sizeof(source)-2){if(c=='\r')c='\n';for(int i=source_len;i>=cur;i--)source[i+1]=source[i];source[cur++]=c;source_len++;source[source_len]=0;repaint();return 0;}}return 0;}
 if(m==WM_PAINT){
  PAINTSTRUCT ps;HDC dc=BeginPaint_(h,&ps);RECT r;GetClientRect_(h,&r);int W=r.right,H=r.bottom;
  if(W<1||H<1){EndPaint_(h,&ps);return 0;}
  HDC mem=CreateCompatibleDC_(dc);HBITMAP bm=mem?CreateCompatibleBitmap_(dc,W,H):0;
  if(!mem||!bm){PatBlt_(dc,0,0,W,H,BLACKNESS);if(bm)DeleteObject_(bm);if(mem)DeleteDC_(mem);EndPaint_(h,&ps);return 0;}
  HGDIOBJ old=SelectObject_(mem,bm);PatBlt_(mem,0,0,W,H,BLACKNESS);if(g_font)SelectObject_(mem,g_font);SetBkMode_(mem,TRANSPARENT);

  /* Outer checker frame: the ornament belongs at the edge, not in the workspace. */
  for(int xx=8,seg=0;xx<W-8;xx+=24,seg++){HGDIOBJ b=SelectObject_(mem,(seg&1)?g_white:g_green);int n=(xx+16<W-8)?16:(W-8-xx);PatBlt_(mem,xx,8,n,2,PATCOPY);PatBlt_(mem,xx,H-10,n,2,PATCOPY);SelectObject_(mem,b);}
  for(int yy=10,seg=0;yy<H-10;yy+=24,seg++){HGDIOBJ b=SelectObject_(mem,(seg&1)?g_white:g_green);int n=(yy+16<H-10)?16:(H-10-yy);PatBlt_(mem,8,yy,2,n,PATCOPY);PatBlt_(mem,W-10,yy,2,n,PATCOPY);SelectObject_(mem,b);}

  /* One telemetry line. */
  if(hud){SetTextColor_(mem,0x00FFFFFF);text(mem,24,20,"DREAM LAND 3.5",-1);SetTextColor_(mem,0x0000FF44);text(mem,164,20,status,-1);}
  SetTextColor_(mem,0x00FFFFFF);text(mem,W-58,20,"[X]",-1);

  /* One blank line, then Dream in its own jewel box. */
  int py=58,ph=34;
  for(int xx=24,seg=0;xx<W-24;xx+=24,seg++){HGDIOBJ b=SelectObject_(mem,(seg&1)?g_white:g_green);int n=(xx+16<W-24)?16:(W-24-xx);PatBlt_(mem,xx,py,n,1,PATCOPY);PatBlt_(mem,xx,py+ph,n,1,PATCOPY);SelectObject_(mem,b);}
  HGDIOBJ wl=SelectObject_(mem,g_white);PatBlt_(mem,24,py,1,ph+1,PATCOPY);PatBlt_(mem,W-25,py,1,ph+1,PATCOPY);SelectObject_(mem,wl);
  SetTextColor_(mem,0x0000FF44);text(mem,38,py+9,"Dream> ",-1);text(mem,101,py+9,prompt,prompt_len);

  /* The rest is black working space. Command mode shows output; edit mode shows source. */
  int cy=108,bottom=H-22;int rows=(bottom-cy)/18;if(rows<1)rows=1;
  if(mode){keep_cursor_visible(rows);draw_source(mem,30,cy,rows);}
  else if(output_len){SetTextColor_(mem,0x0000BB33);draw_output(mem,30,cy,rows);}

  /* Four very slow edge sparks; calm removes the timer entirely. */
  if(sparkle){static const int sx[4]={80,360,720,1040};for(int q=0;q<4;q++){if(((twinkle_phase+q)%9)==0){SetTextColor_(mem,0x00FFFFFF);text(mem,sx[q]%(W-40)+20,H-18,"+",1);}}}

  /* Native Win32 caret: zero repaint cost for blinking. */
  if(SetCaretPos_){if(!mode)SetCaretPos_(101+prompt_len*9,py+9);else{int row=cursor_line()-view_line,col=0,p=cur;while(p>0&&source[p-1]!='\n'){p--;col++;}if(row>=0&&row<rows)SetCaretPos_((line_numbers?78:30)+col*9,cy+row*18);}}

  BitBlt_(dc,0,0,W,H,mem,0,0,SRCCOPY);SelectObject_(mem,old);DeleteObject_(bm);DeleteDC_(mem);EndPaint_(h,&ps);return 0;}
 return DefWindowProcA_(h,m,w,l);
}

static int api_load(void){HMODULE u=LoadLibraryA("user32.dll"),g=LoadLibraryA("gdi32.dll"),k=LoadLibraryA("kernel32.dll");if(!u||!g||!k)return 0;
 #define GP(x,m,n,t) x=(t)GetProcAddress(m,n);if(!x)return 0
 GP(RegisterClassA_,u,"RegisterClassA",pRegisterClassA);GP(CreateWindowExA_,u,"CreateWindowExA",pCreateWindowExA);GP(ShowWindow_,u,"ShowWindow",pShowWindow);GP(UpdateWindow_,u,"UpdateWindow",pUpdateWindow);GP(GetMessageA_,u,"GetMessageA",pGetMessageA);GP(TranslateMessage_,u,"TranslateMessage",pTranslateMessage);GP(DispatchMessageA_,u,"DispatchMessageA",pDispatchMessageA);GP(DefWindowProcA_,u,"DefWindowProcA",pDefWindowProcA);GP(PostQuitMessage_,u,"PostQuitMessage",pPostQuitMessage);GP(InvalidateRect_,u,"InvalidateRect",pInvalidateRect);GP(BeginPaint_,u,"BeginPaint",pBeginPaint);GP(EndPaint_,u,"EndPaint",pEndPaint);GP(GetClientRect_,u,"GetClientRect",pGetClientRect);GP(LoadCursorA_,u,"LoadCursorA",pLoadCursorA);GP(SendMessageA_,u,"SendMessageA",pSendMessageA);GP(DestroyWindow_,u,"DestroyWindow",pDestroyWindow);GP(SetTimer_,u,"SetTimer",pSetTimer);GP(KillTimer_,u,"KillTimer",pKillTimer);GP(CreateCaret_,u,"CreateCaret",pCreateCaret);GP(ShowCaret_,u,"ShowCaret",pShowCaret);GP(HideCaret_,u,"HideCaret",pHideCaret);GP(DestroyCaret_,u,"DestroyCaret",pDestroyCaret);GP(SetCaretPos_,u,"SetCaretPos",pSetCaretPos);
 GP(CreateCompatibleDC_,g,"CreateCompatibleDC",pCreateCompatibleDC);GP(DeleteDC_,g,"DeleteDC",pDeleteDC);GP(CreateCompatibleBitmap_,g,"CreateCompatibleBitmap",pCreateCompatibleBitmap);GP(SelectObject_,g,"SelectObject",pSelectObject);GP(DeleteObject_,g,"DeleteObject",pDeleteObject);GP(BitBlt_,g,"BitBlt",pBitBlt);GP(SetTextColor_,g,"SetTextColor",pSetTextColor);GP(SetBkMode_,g,"SetBkMode",pSetBkMode);GP(TextOutA_,g,"TextOutA",pTextOutA);GP(PatBlt_,g,"PatBlt",pPatBlt);GP(CreateFontA_,g,"CreateFontA",pCreateFontA);GP(CreateSolidBrush_,g,"CreateSolidBrush",pCreateSolidBrush);GP(GetModuleHandleA_,k,"GetModuleHandleA",pGetModuleHandleA);return 1;
}
int dream_gui_main(void){if(!api_load())ExitProcess(3);HINSTANCE hi=GetModuleHandleA_(0);WNDCLASSA wc;d_u8*z=(d_u8*)&wc;for(int i=0;i<(int)sizeof(wc);i++)z[i]=0;g_black=CreateSolidBrush_(0x00000000);g_green=CreateSolidBrush_(0x0000FF44);g_white=CreateSolidBrush_(0x00FFFFFF);wc.style=CS_HREDRAW|CS_VREDRAW;wc.lpfnWndProc=WndProc;wc.hInstance=hi;wc.hCursor=LoadCursorA_(0,IDC_ARROW);wc.hbrBackground=g_black;wc.lpszClassName="DREAM53";if(!RegisterClassA_(&wc))ExitProcess(4);g_font=CreateFontA_(-16,0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,FIXED_PITCH|FF_MODERN,"Consolas");g_hwnd=CreateWindowExA_(0,"DREAM53","DREAM LAND",WS_POPUP|WS_THICKFRAME|WS_SYSMENU|WS_MINIMIZEBOX|WS_MAXIMIZEBOX,CW_USEDEFAULT,CW_USEDEFAULT,1160,800,0,0,hi,0);if(!g_hwnd)ExitProcess(5);
 source[0]=0;source_len=0;cur=0;view_line=0;out_clear();
 ShowWindow_(g_hwnd,SW_SHOW);InvalidateRect_(g_hwnd,0,1);UpdateWindow_(g_hwnd);
 if(CreateCaret_&&ShowCaret_){CreateCaret_(g_hwnd,0,2,14);ShowCaret_(g_hwnd);RECT cr;if(GetClientRect_(g_hwnd,&cr)&&SetCaretPos_)SetCaretPos_(101,67);}
 if(sparkle)SetTimer_(g_hwnd,timer_id,2300,0);MSG msg;while(GetMessageA_(&msg,0,0,0)>0){TranslateMessage_(&msg);DispatchMessageA_(&msg);}ExitProcess(0);return 0;}
