#include "dream3_core.h"
#include "dream_metal.h"
#include "dream_cbridge.h"

typedef d_u32 DWORD; typedef d_i32 BOOL; typedef d_u32 UINT; typedef d_u16 WORD; typedef d_u8 BYTE; typedef void* HANDLE; typedef void* HMODULE;
#define MS D3_MS
extern HANDLE MS CreateFileA(const char*,DWORD,DWORD,void*,DWORD,DWORD,HANDLE);
extern BOOL MS ReadFile(HANDLE,void*,DWORD,DWORD*,void*);
extern BOOL MS WriteFile(HANDLE,const void*,DWORD,DWORD*,void*);
extern BOOL MS CloseHandle(HANDLE); extern HANDLE MS GetStdHandle(DWORD);
extern char* MS GetCommandLineA(void); extern void MS ExitProcess(UINT);
extern HMODULE MS LoadLibraryA(const char*); extern void* MS GetProcAddress(HMODULE,const char*);
#define STD_OUTPUT_HANDLE ((DWORD)-11)
#define GENERIC_READ 0x80000000u
#define GENERIC_WRITE 0x40000000u
#define FILE_SHARE_READ 1
#define OPEN_EXISTING 3
#define CREATE_ALWAYS 2
#define FILE_ATTRIBUTE_NORMAL 0x80
#define INVALID_HANDLE_VALUE ((HANDLE)(d_i64)-1)
#define INFINITE 0xffffffffu
#define CREATE_NO_WINDOW 0x08000000u

typedef struct {
 DWORD cb; char*lpReserved;char*lpDesktop;char*lpTitle;DWORD dwX,dwY,dwXSize,dwYSize,dwXCountChars,dwYCountChars,dwFillAttribute,dwFlags;WORD wShowWindow,cbReserved2;BYTE*lpReserved2;HANDLE hStdInput,hStdOutput,hStdError;
} DSTARTUPINFOA;
typedef struct {HANDLE hProcess,hThread;DWORD dwProcessId,dwThreadId;} DPROCESS_INFORMATION;
_Static_assert(sizeof(DSTARTUPINFOA)==104,"STARTUPINFOA");_Static_assert(sizeof(DPROCESS_INFORMATION)==24,"PROCESS_INFORMATION");
typedef BOOL (MS *pCreateProcessA)(const char*,char*,void*,void*,BOOL,DWORD,void*,const char*,DSTARTUPINFOA*,DPROCESS_INFORMATION*);
typedef DWORD (MS *pWaitForSingleObject)(HANDLE,DWORD);typedef BOOL (MS *pGetExitCodeProcess)(HANDLE,DWORD*);

static HANDLE ho; static char source[262144]; static D3Program prog; static DCB bridge;
static d_u8 metal[DM_MAX],coff[DM_MAX+128]; static char cgen[8*1024*1024]; static char cmdline[16384];
static void say(const char*s){DWORD w=0;WriteFile(ho,s,(DWORD)d3_len(s),&w,0);}
static void arg(char*out,int nth){char*p=GetCommandLineA();int n=0;while(*p){while(*p==' ')p++;if(!*p)break;int q=0;if(*p=='\"'){q=1;p++;}char*d=out;while(*p&&((q&&*p!='\"')||(!q&&*p!=' ')))*d++=*p++;*d=0;if(q&&*p=='\"')p++;if(n++==nth)return;}out[0]=0;}
static int write_file(const char*fn,const void*data,int bytes){HANDLE f=CreateFileA(fn,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);if(f==INVALID_HANDLE_VALUE)return 0;DWORD w=0;BOOL ok=WriteFile(f,data,(DWORD)bytes,&w,0);CloseHandle(f);return ok&&w==(DWORD)bytes;}
static int run_cmd(char*cmd){HMODULE k=LoadLibraryA("kernel32.dll");if(!k)return -1;pCreateProcessA cp=(pCreateProcessA)GetProcAddress(k,"CreateProcessA");pWaitForSingleObject wait=(pWaitForSingleObject)GetProcAddress(k,"WaitForSingleObject");pGetExitCodeProcess code=(pGetExitCodeProcess)GetProcAddress(k,"GetExitCodeProcess");if(!cp||!wait||!code)return -1;DSTARTUPINFOA si;DPROCESS_INFORMATION pi;dcb_zero(&si,(int)sizeof(si));dcb_zero(&pi,(int)sizeof(pi));si.cb=(DWORD)sizeof(si);if(!cp(0,cmd,0,0,0,CREATE_NO_WINDOW,0,0,&si,&pi))return -1;wait(pi.hProcess,INFINITE);DWORD ec=1;code(pi.hProcess,&ec);CloseHandle(pi.hThread);CloseHandle(pi.hProcess);return (int)ec;}

int dreamcc_main(void){
 ho=GetStdHandle(STD_OUTPUT_HANDLE);char a1[260],in[260],out[260],nb[32];arg(a1,1);int mode=0,ai=1;
 if(d3_eq(a1,"--metal")){mode=1;ai=2;}else if(d3_eq(a1,"--coff")){mode=2;ai=2;}else if(d3_eq(a1,"--cgen")){mode=3;ai=2;}else if(d3_eq(a1,"--cbuild")){mode=4;ai=2;}
 arg(in,ai);arg(out,ai+1);if(!in[0])d3_copy(in,"dream.dc",260);if(!out[0])d3_copy(out,mode==1?"dream.bin":mode==2?"dream.obj":mode==3?"dream_native.c":mode==4?"dream_native.exe":"dream.dvm",260);
 HANDLE f=CreateFileA(in,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);if(f==INVALID_HANDLE_VALUE){say("dreamcc: cannot open source\r\n");ExitProcess(2);}DWORD r=0;ReadFile(f,source,sizeof(source)-1,&r,0);CloseHandle(f);source[r]=0;
 if(mode==1||mode==2){char er[160];int n=0;if(!dm_extract(source,metal,DM_MAX,&n,er,160)){say("dreamcc metal: ");say(er);say("\r\n");ExitProcess(3);}const d_u8*data=metal;int bytes=n;if(mode==2){bytes=dm_coff(metal,n,coff,DM_MAX+128);data=coff;if(!bytes){say("dreamcc: COFF image too large\r\n");ExitProcess(3);}}if(!write_file(out,data,bytes))ExitProcess(4);say(mode==2?"dreamcc: COFF OK -> ":"dreamcc: METAL OK -> ");say(out);say("\r\n");ExitProcess(0);}
 if(!dcb_prepare(&bridge,source)){say("dreamcc bridge: ");say(bridge.error);say("\r\n");ExitProcess(3);}
 if(!d3_compile(&prog,bridge.dream)){say("dreamcc: line ");d3_i64str(prog.error_line,nb);say(nb);say(": ");say(prog.error);say("\r\n");ExitProcess(3);}
 if(mode==3||mode==4){int gn=dcb_generate_c(&bridge,&prog,cgen,(int)sizeof(cgen));if(!gn){say("dreamcc: native C generation failed\r\n");ExitProcess(5);}const char*cfile=mode==3?out:"dream_native.c";if(!write_file(cfile,cgen,gn)){say("dreamcc: cannot write native C\r\n");ExitProcess(5);}if(mode==3){say("dreamcc: C BRIDGE OK -> ");say(out);say("\r\n");ExitProcess(0);}if(!dcb_build_command(&bridge,cfile,out,cmdline,(int)sizeof(cmdline),"gcc")){say("dreamcc: build command too large\r\n");ExitProcess(5);}char full[16384];int fn=0;dcb_cat(full,&fn,sizeof(full),"cmd.exe /c ");dcb_cat(full,&fn,sizeof(full),cmdline);int ec=run_cmd(full);if(ec!=0){fn=0;dcb_build_command(&bridge,cfile,out,cmdline,(int)sizeof(cmdline),"clang");dcb_cat(full,&fn,sizeof(full),"cmd.exe /c ");dcb_cat(full,&fn,sizeof(full),cmdline);ec=run_cmd(full);}if(ec!=0){say("dreamcc: C BUILD FAILED // install GCC or Clang and check link/cflag directives\r\n");ExitProcess(6);}say("dreamcc: C BUILD OK -> ");say(out);say("\r\n");ExitProcess(0);}
 D3Head h={{'D','R','M','3'},3,(d_u32)prog.ncode,(d_u32)prog.nvars,0};f=CreateFileA(out,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);if(f==INVALID_HANDLE_VALUE)ExitProcess(4);DWORD w=0;WriteFile(f,&h,sizeof(h),&w,0);WriteFile(f,prog.code,(DWORD)(prog.ncode*sizeof(D3Ins)),&w,0);CloseHandle(f);say("dreamcc: COMPILE OK // ");d3_i64str(prog.ncode,nb);say(nb);say(" ops -> ");say(out);say("\r\n");ExitProcess(0);return 0;
}
