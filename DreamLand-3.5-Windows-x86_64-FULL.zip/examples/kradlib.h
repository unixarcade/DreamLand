#ifndef KRADLIB_H
#define KRADLIB_H
long long krad_add(long long a,long long b);
#endif
