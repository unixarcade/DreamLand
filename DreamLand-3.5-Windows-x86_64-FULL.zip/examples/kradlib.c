#include "kradlib.h"
long long krad_add(long long a,long long b){ return a + b + 5300; }
