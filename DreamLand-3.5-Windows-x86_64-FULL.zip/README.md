# DREAM LAND 3.5 // ONE-LINE TELEMETRY EDITION

Dream Land 3.5 keeps the machinery and removes visual noise.

## Main surface

- one telemetry line
- one blank line
- `Dream>` inside its own small checker-trimmed command box
- uninterrupted black working field below
- white/neon-green checker frame around the entire environment
- no maker/support names on the main screen; those live in `man greetz`
- native Win32 white caret; cursor blinking does not cause full-window repaints
- optional very slow edge sparkle; `calm` removes the timer entirely

## Tiny language additions

Dream now supports compile-time constants:

    macro LIMIT = 8;
    macro GREEN = "\e[92m";

Dream string escapes now include `\e` = ASCII ESC, so terminal/native builds can
use ANSI sequences directly:

    print(GREEN, "hello", "\e[0m");

This is deliberately tiny: there is no new macro language or preprocessor.
Macros are number/string constants and are compiled straight into ordinary
Dream literals.

## Discovery

    list
    search TERM
    man TOPIC
    man macro
    man ansi
    man example
    man greetz

## Identity / support

Available via `man greetz` or `greetz`, not the landing screen.
